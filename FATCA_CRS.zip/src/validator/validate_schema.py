from __future__ import annotations

from dataclasses import is_dataclass
from pathlib import Path
from typing import Any, Iterable, Union, Optional

from lxml import etree

# xsdata is used here for (optional) dataclass -> XML serialization
from xsdata.formats.dataclass.serializers import XmlSerializer
from xsdata.formats.dataclass.serializers.config import SerializerConfig


XmlInput = Union[
    str,                      # xml string OR path
    bytes,                    # xml bytes
    Path,                     # xml file path
    etree._Element,           # lxml element
    etree._ElementTree,       # lxml element tree
    Any                       # optionally an xsdata-generated dataclass instance
]


def _load_schema(xsd_path: Union[str, Path]) -> etree.XMLSchema:
    """
    Load and compile an XSD schema.
    """
    xsd_path = Path(xsd_path)
    with xsd_path.open("rb") as f:
        schema_doc = etree.parse(f)
    return etree.XMLSchema(schema_doc)


def _to_etree(xml: XmlInput) -> etree._ElementTree:
    """
    Normalize various XML inputs into an lxml ElementTree.
    - If a dataclass instance is provided, serialize it using xsdata first.
    """
    # 1) Already an ElementTree
    if isinstance(xml, etree._ElementTree):
        return xml

    # 2) An Element (wrap into ElementTree)
    if isinstance(xml, etree._Element):
        return etree.ElementTree(xml)

    # 3) Path-like / string path
    if isinstance(xml, (Path, str)):
        p = Path(xml)
        if isinstance(xml, str) and xml.lstrip().startswith("<"):
            # looks like an XML string
            root = etree.fromstring(xml.encode("utf-8"))
            return etree.ElementTree(root)
        if p.exists():
            return etree.parse(str(p))

    # 4) Raw bytes (XML document)
    if isinstance(xml, (bytes, bytearray)):
        root = etree.fromstring(bytes(xml))
        return etree.ElementTree(root)

    # 5) xsdata dataclass instance -> serialize -> parse
    if is_dataclass(xml):
        serializer = XmlSerializer(config=SerializerConfig(pretty_print=False))
        xml_str = serializer.render(xml)
        root = etree.fromstring(xml_str.encode("utf-8"))
        return etree.ElementTree(root)

    raise TypeError(
        "Unsupported xml input. Provide an lxml Element/ElementTree, "
        "an XML string/bytes, a file path, or an xsdata dataclass instance."
    )


def validate_xml(
    xml: XmlInput,
    xsd_path: Union[str, Path],
    *,
    fail_fast: bool = False
) -> tuple[bool, list[str]]:
    """
    Validate XML against XSD.

    Returns:
        (is_valid, errors)
    """
    schema = _load_schema(xsd_path)
    doc = _to_etree(xml)

    if fail_fast:
        # Raises etree.DocumentInvalid on failure (fast exit)
        try:
            schema.assertValid(doc)
            return True, []
        except etree.DocumentInvalid as e:
            # schema.error_log contains detailed messages/locations
            errors = [str(err) for err in schema.error_log]
            # include exception summary first
            return False, [str(e)] + errors

    # Non-raising validation
    is_valid = schema.validate(doc)
    errors = [str(err) for err in schema.error_log]
    return is_valid, errors


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Validate XML against an XSD schema.")
    parser.add_argument("xml", help="Path to XML file (or literal XML string)")
    parser.add_argument("xsd", help="Path to XSD schema file")
    parser.add_argument("--fail-fast", action="store_true", help="Raise on first invalidity")
    args = parser.parse_args()

    ok, errs = validate_xml(args.xml, args.xsd, fail_fast=args.fail_fast)
    if ok:
        print("✓ XML is valid")
    else:
        print("✗ XML is invalid")
        for e in errs:
            print("  -", e)