import math
import os
from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
from xsdata.formats.dataclass.serializers import XmlSerializer
from xsdata.formats.dataclass.serializers.config import SerializerConfig
from xsdata.models.datatype import XmlDate, XmlDateTime

from schema.crs2.crs2_schema import (
    CorrectableOrganisationPartyType,
    CountryCodeType,
    CrsBodyType,
    CrsMessageTypeIndicEnumType,
    CrsOecd,
    MessageSpecType,
    MessageTypeEnumType,
    NameOrganisationType,
    OrganisationInType,
)
from src.crs2.crs_builders import (
    _parse_xmldate,
    _parse_xmldatetime,
    build_address,
    build_doc_spec,
    build_reportable_indiv,
    build_reportable_org,
)
from src.crs2.read_excel_const import CONST as CONST

NUMBER_ENTRIES = 200
DEBUGMODE = False
SCHEMA_VERSION = "3.0"


AMP_GUARD = r"&(?!(amp|apos|lt|gt|quot);)"
REPLACE_SPECIAL_CHAR = {
    "#": "",  # remove
    "--": "",  # remove
    "/*": "",  # remove
    "'": "&apos;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
}

SHEETS_TO_READ = [
    CONST.SHEET_MSG_HEADER,
    CONST.SHEET_REPORTING_FI,
    CONST.SHEET_REPORTABLE_INDIV_ACC,
    CONST.SHEET_REPORTABLE_ORG_ACC,
    CONST.SHEET_CONTROLLING_PERSON,
]


def sanitize_df_using_lookup(df: pd.DataFrame, cols=None, remove_to=""):
    out = df.copy()

    if cols is None:
        cols = out.select_dtypes(include=["object", "string"]).columns

    for c in cols:
        s = out[c].astype("string")

        # 1) remove the "none" patterns (from lookup)
        for k in ["#", "--", "/*"]:
            s = s.str.replace(k, remove_to, regex=False)

        # 2) ampersand escape with guard (avoid double-escaping existing entities)
        s = s.str.replace(AMP_GUARD, "&amp;", regex=True)

        # 3) apply the remaining entity replacements from lookup table
        for k in ["'", "<", ">", '"']:
            s = s.str.replace(k, REPLACE_SPECIAL_CHAR[k], regex=False)

        out[c] = s

    return out


class CRS_template:
    def __init__(
        self,
        infile: str,
        outpath: str,
    ) -> None:
        """
        parameter:
            infile: excel file
            outpath: output path -> will give 3 outputs: processed lines, error, XML(s),
        """
        self.infile = infile
        self.outpath = outpath
        self.outfile_error = os.path.join(
            self.outpath, os.path.splitext(os.path.basename(infile))[0] + "_error.xlsx"
        )
        self.outfile_processed = os.path.join(
            self.outpath,
            os.path.splitext(os.path.basename(infile))[0] + "_processed.xlsx",
        )
        self.outfile_XML = os.path.join(
            self.outpath, os.path.splitext(os.path.basename(infile))[0] + "_[XX].XML"
        )

        self.dfs = None
        self.reportable_jurisdiction = None
        # Validate file exists
        self._file_exists(infile)
        self.msg_header = None
        self.reporting_FI = None
        self.reporting_period = None
        self.sending_company_in = None
        self.doc_spec = None
        self.reportable_indiv = None
        self.reportable_org = None
        self.reporting_group = None
        self.crs_documents = []
        self.XMLs = []

    def _file_exists(self, infile) -> bool:
        """
        Validate that `infile` is a readable, existing file.

        Args:
            infile: Path-like (str / Path / os.PathLike)

        Returns:
            Path: Normalized Path object for the input file.

        Raises:
            ValueError: If infile is None or empty/blank string.
            TypeError: If infile is not path-like.
            FileNotFoundError: If the path does not exist.
            IsADirectoryError: If the path exists but is not a file.
            PermissionError: If the file exists but is not readable.
            OSError: For other OS-level issues while probing the file.
        """
        if infile is None:
            raise ValueError("infile is None")

        if isinstance(infile, str) and not infile.strip():
            raise ValueError("infile is an empty/blank string")

        try:
            path = Path(infile).expanduser()
        except TypeError as e:
            raise TypeError(
                f"infile must be a path-like object (got {type(infile).__name__})"
            ) from e

        if not path.exists():
            raise FileNotFoundError(f"Input file not found: {path}")

        if not path.is_file():
            raise IsADirectoryError(
                f"Expected a file but got a directory/other: {path}"
            )

        # Check readability (more reliable than os.access on some platforms)
        try:
            with path.open("rb"):
                pass
        except PermissionError as e:
            raise PermissionError(
                f"Input file exists but is not readable: {path}"
            ) from e
        except OSError as e:
            raise OSError(f"Unable to open input file ({path}): {e}") from e

        return path

    def _read_msg_header(self, df: pd.DataFrame):
        if len(df) != 1:
            raise ValueError("Message Header should only have 1 row")

        row = df.iloc[0].to_dict()

        # Pull & clean strings
        reporting_period = _parse_xmldate(row.get(CONST.COL_REPORTINGPERIOD))
        sending_company_in = row.get(CONST.COL_SENDINGCOMPANYIN)
        transmitting_country = row.get(CONST.COL_TRANSMITTINGCOUNTRY)
        receiving_country = row.get(CONST.COL_RECEIVINGCOUNTRY)
        message_type = row.get(CONST.COL_MESSAGETYPE)
        message_ref_id = (
            str(reporting_period)[:4]
            + str(datetime.now().strftime("%Y%m%d"))
            + str(row.get(CONST.COL_MESSAGEREFID))
        )
        message_type_indic = row.get(CONST.COL_MESSAGETYPEINDIC)
        timestamp = _parse_xmldatetime(row.get(CONST.COL_TIMESTAMP))

        self.reporting_period = reporting_period
        self.sending_company_in = sending_company_in

        # Now convert to schema types/enums depending on your generated classes:
        self.msg_header = MessageSpecType(
            sending_company_in=sending_company_in,
            transmitting_country=CountryCodeType(transmitting_country),
            receiving_country=CountryCodeType(receiving_country),
            message_type=MessageTypeEnumType(message_type),
            warning=None,  # omit unless you have a non-empty value
            contact=None,  # omit unless you have a non-empty value
            message_ref_id=message_ref_id,
            message_type_indic=CrsMessageTypeIndicEnumType(message_type_indic),
            corr_message_ref_id=None,
            reporting_period=reporting_period,
            timestamp=timestamp,
        )

        if DEBUGMODE:
            print(rf"msgheader: \n {self.msg_header}")

        return True

    def _read_reporting_FI(
        self,
        df: pd.DataFrame,
    ):
        if len(df) != 1:
            raise ValueError("Message Header should only have 1 row")

        row = df.iloc[0].to_dict()

        # Pull & clean strings
        res_country_code = row.get(CONST.COL_RESCOUNTRYCODE)
        in_value = row.get(CONST.COL_IN)
        name = row.get(CONST.COL_NAME)
        address = build_address(row)
        doc_spec = build_doc_spec(row,self.reporting_period, self.sending_company_in)
        self.doc_spec = doc_spec

        # Now convert to schema types/enums depending on your generated classes:
        self.reporting_FI = CorrectableOrganisationPartyType(
            res_country_code=[CountryCodeType(res_country_code)],
            in_value=[OrganisationInType(value=in_value)],
            name=[NameOrganisationType(value=name)],
            address=address,
            doc_spec=doc_spec,
        )

        if DEBUGMODE:
            print(f"Reporting FI: \n {self.reporting_FI}")

        return True

    def _read_reportable_indv(
        self,
        df: pd.DataFrame,
    ):
        rows = df.to_dict(orient="records")
        self.reportable_indiv = build_reportable_indiv(
            rows=rows,
            reporting_period=self.reporting_period,
            sending_company_in=self.sending_company_in,
        )

        if DEBUGMODE:
            print(f"Reportable Indiv: \n {self.reportable_indiv}")

    def _read_reportable_org(
        self,
        df_org: pd.DataFrame,
        df_controlling_person: pd.DataFrame,
    ):
        rows_org = df_org.to_dict(orient="records")
        rows_controlling_person = (
            df_controlling_person.drop(
                columns=[CONST.COL_ACCOUNTNUMBER], errors="ignore"
            )
            .groupby(df_controlling_person[CONST.COL_ACCOUNTNUMBER], dropna=False)
            .apply(lambda g: g.to_dict("records"))
            .to_dict()
        )

        self.reportable_org = build_reportable_org(
            rows=rows_org,
            rows_controlling_person=rows_controlling_person,
            reporting_period=self.reporting_period,
            sending_company_in=self.sending_company_in,
        )

        if DEBUGMODE:
            print(f"Reportable Org: \n {self.reportable_org}")

        pass

    def read_excel(
        self,
        engine: str = "openpyxl",
    ):
        if not self._file_exists(self.infile):
            return -1

        path = self.infile

        try:
            xl = pd.ExcelFile(path, engine=engine)
        except PermissionError as e:
            raise PermissionError(
                f"Cannot open Excel file (permission denied): {path}"
            ) from e
        except Exception as e:
            raise OSError(f"Failed to open Excel file: {path} ({e})") from e

        available = set(xl.sheet_names)
        missing = [s for s in SHEETS_TO_READ if s not in available]
        if missing:
            raise ValueError(
                "Missing required sheet(s): "
                + ", ".join(missing)
                + f". Available sheets: {xl.sheet_names}"
            )

        # Read only the target sheets; pandas returns a dict: {sheet_name: DataFrame}
        try:
            self.dfs = pd.read_excel(
                xl,
                sheet_name=SHEETS_TO_READ,
                dtype="str",
            )

            self.dfs = {
                n: sanitize_df_using_lookup(
                    d.replace(r"^\s*$", np.nan, regex=True)  # empty/whitespace -> NaN
                    .astype(object)  # allow Python None
                    .where(pd.notna(d), None)  # NaN/pd.NA -> None
                )
                for n, d in self.dfs.items()
            }

            self.reportable_jurisdiction = (
                pd.read_excel(
                    xl,
                    sheet_name=CONST.SHEET_REPORTABLE_JURISDICTION,
                    usecols="A",
                    engine="openpyxl",
                )
                .set_axis([CONST.COL_REPORTABLE_JURISDICTION], axis=1)[
                    CONST.COL_REPORTABLE_JURISDICTION
                ]
                .dropna()
                .astype(str)
                .tolist()
            )

        except Exception as e:
            raise OSError(f"Failed while reading sheets from {path}: {e}") from e

        self.dfs_reportable = [
            df[
                df[CONST.COL_CHECK_REPORTABLE]
                .astype("string")
                .str.strip()
                .isin(["TRUE", ""])
            ]
            for df in self.dfs
        ]

        self._read_msg_header(self.dfs[CONST.SHEET_MSG_HEADER])
        self._read_reporting_FI(self.dfs[CONST.SHEET_REPORTING_FI])
        self._read_reportable_indv(self.dfs[CONST.SHEET_REPORTABLE_INDIV_ACC])
        self._read_reportable_org(
            self.dfs[CONST.SHEET_REPORTABLE_ORG_ACC],
            self.dfs[CONST.SHEET_CONTROLLING_PERSON],
        )
        self.reporting_group = self.reportable_org + self.reportable_indiv

        type(self.reporting_group)

    def build_crs_documents(
        self,
    ) -> list[CrsOecd]:

        self.crs_documents = []

        number_of_files = math.ceil(len(self.reporting_group) / NUMBER_ENTRIES)
        message_ref_id_template = self.msg_header.message_ref_id

        for i in range(number_of_files):
            self.msg_header.message_ref_id = message_ref_id_template + str(
                ("000" + str(i))[-3:]
            )
            rg = CrsBodyType.ReportingGroup(
                sponsor=None,
                intermediary=None,
                account_report=self.reporting_group,
                pool_report=[],
            )
            self.crs_documents.append(
                CrsOecd(
                    message_spec=self.msg_header,
                    crs_body=[
                        CrsBodyType(
                            reporting_fi=self.reporting_FI,
                            reporting_group=[rg],
                        )
                    ],
                    version=SCHEMA_VERSION,
                )
            )
        return self.crs_documents

    def write_xml(self, output_path) -> list[str]:
        NS_MAP = {
            "crs": "urn:oecd:ties:crs:v2",
            "cfc": "urn:oecd:ties:commontypesfatcacrs:v2",
            "stf": "urn:oecd:ties:crsstf:v5",
            "iso": "urn:oecd:ties:isocrstypes:v1",
            "xsi": "http://www.w3.org/2001/XMLSchema-instance",
        }

        self.XMLs = []
        objs = self.build_crs_documents()

        serializer = XmlSerializer(
            config=SerializerConfig(
                pretty_print=True,
                xml_declaration=True,
                encoding="UTF-8",
            )
        )
        p = Path(output_path)
        out_dir = p.parent if p.suffix else p
        for obj in objs:
            out_file = out_dir / f"{obj.message_spec.message_ref_id}.xml"
            xml_text = serializer.render(obj, ns_map=NS_MAP)
            self.XMLs.append(xml_text)
            Path(out_file).write_text(xml_text, encoding="utf-8")
        return self.XMLs
