from schema.crs2.crs2_schema import (
    CountryCodeType,
    CurrCodeType,
    CrsMessageTypeIndicEnumType,
)


class CONST:
    SHEET_MSG_HEADER = "Message Header"
    SHEET_REPORTING_FI = "Reporting FI"
    SHEET_REPORTABLE_INDIV_ACC = "Reportable Individual Account"
    SHEET_REPORTABLE_ORG_ACC = "Reportable Organisation Account"
    SHEET_CONTROLLING_PERSON = "Controlling Person (Individual)"
    SHEET_REPORTABLE_JURISDICTION = "Reportable Jurisdictions"

    # -- Message Header -- #
    COL_SENDINGCOMPANYIN = "SendingCompanyIN"
    COL_TRANSMITTINGCOUNTRY = "TransmittingCountry"
    COL_RECEIVINGCOUNTRY = "ReceivingCountry"
    COL_MESSAGETYPE = "MessageType"
    COL_WARNING = "Warning"
    COL_CONTACT = "Contact"
    COL_MESSAGEREFID = "MessageRefID"
    COL_MESSAGETYPEINDIC = "MessageTypeIndic"
    COL_REPORTINGPERIOD = "ReportingPeriod"
    COL_TIMESTAMP = "Timestamp"

    # -- Reporting FI -- #
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_IN = "IN"
    COL_NAME = "Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_CORRMSGREFID = "CorrMessageRefID"

    # -- Reportable Individual Account -- #
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_TIN = "TIN"
    COL_TIN_ISSUED_BY = "TIN_Issued_By"
    COL_FIRST_NAME = "First_Name"
    COL_MIDDLE_NAME = "Middle_Name"
    COL_LAST_NAME = "Last_Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"  ## Need to update to address Fix
    COL_ADDRESSFREE = "AddressFree"
    COL_BIRTHDATE = "BirthDate"
    COL_ACCOUNT_BALANCE = "Account_Balance"
    COL_CURRCODE = "currCode"
    COL_DIVIDENDS_PAYMENT_AMOUNT = "Dividends_Payment_Amount"
    COL_DIVIDENDS_PAYMENT_CURRCODE = "Dividends_Payment_CurrCode"
    COL_INTEREST_PAYMENT_AMOUNT = "Interest_Payment_Amount"
    COL_INTEREST_PAYMENT_CURRCODE = "Interest_Payment_CurrCode"
    COL_GROSS_PROCEEDS_PAYMENT_AMOUNT = "Gross_Proceeds_Payment_Amount"
    COL_GROSS_PROCEEDS_PAYMENT_CURRCODE = "Gross_Proceeds_Payment_CurrCode"
    COL_OTHER_PAYMENT_AMOUNT = "Other_Payment_Amount"
    COL_OTHER_PAYMENT_CURRCODE = "Other_Payment_CurrCode"
    COL_ACCOUNT_CLOSED = "Account_Closed?"
    COL_ACCOUNT_UNDOCUMENTED = "Account_Undocumented?"

    # -- Reportable Organisation Account -- #
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_IN = "IN"
    COL_IN_ISSUED_BY = "IN_issued_by"
    COL_NAME = "Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ACCTHOLDERTYPE = "AcctHolderType"
    COL_ACCOUNT_BALANCE = "Account_Balance"
    COL_CURRCODE = "currCode"
    COL_DIVIDENDS_PAYMENT_AMOUNT = "Dividends_Payment_Amount"
    COL_DIVIDENDS_PAYMENT_CURRCODE = "Dividends_Payment_CurrCode"
    COL_INTEREST_PAYMENT_AMOUNT = "Interest_Payment_Amount"
    COL_INTEREST_PAYMENT_CURRCODE = "Interest_Payment_CurrCode"
    COL_GROSS_PROCEEDS_PAYMENT_AMOUNT = "Gross_Proceeds_Payment_Amount"
    COL_GROSS_PROCEEDS_PAYMENT_CURRCODE = "Gross_Proceeds_Payment_CurrCode"
    COL_OTHER_PAYMENT_AMOUNT = "Other_Payment_Amount"
    COL_OTHER_PAYMENT_CURRCODE = "Other_Payment_CurrCode"

    # -- Controlling Person (Individual) -- #
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_TIN = "TIN"
    COL_TIN_ISSUED_BY = "TIN_Issued_By"
    COL_FIRST_NAME = "First_Name"
    COL_MIDDLE_NAME = "Middle_Name"
    COL_LAST_NAME = "Last_Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"
    COL_BIRTHDATE = "BirthDate"
    COL_CTRLGPERSONTYPE = "CtrlgPersonType"

    # -- Address fix / Free -- #
    COL_ADDRESSFREE = "AddressFree"
    COL_ADDRESSFIX_STREET = "Street"
    COL_ADDRESSFIX_BUILDINGID = "Building Identifier"
    COL_ADDRESSFIX_SUITEID = "Suite Identifier"
    COL_ADDRESSFIX_FLOORID = "Floor Identifier"
    COL_ADDRESSFIX_DISTRICT_NAME = "District Name"
    COL_ADDRESSFIX_POB = "POB"
    COL_ADDRESSFIX_POST_CODE = "Post Code"
    COL_ADDRESSFIX_CITY = "City"
    COL_ADDRESSFIX_COUNTRY_SUBENTITY = "Country Subentity"

    # -- Reportable Jurisdiction
    COL_REPORTABLE_JURISDICTION = "ResCountryCode /\nTINissuedBy"

    # -- Validation checks
    COL_CHECK_REPORTABLE = "Reportable?"
    COL_CHECK_ERROR = "Error"
    COL_CHECK_WARNING = "Warning"

    # -- Other Constants list
    _IRAS_IN_LIST = ["IRAS101", "IRAS102", "IRAS103", "IRAS104"]
    _OECD_DOC_TYPE = ["OECD1", "OECD2", "OECD3"]
    _ACCT_HOLDER_TYPE = ["CRS101", "CRS102", "CRS103"]
    _MESSAGE_TYPE_INDIC = ["CRS701", "CRS702", "CRS703"]
    _ENTITY_ID_TYPE = ["UEN-Business", "UEN-Local Co", "UEN-Others", "ASGD", "ITR"] 
    VALID_IN = {e for e in _IRAS_IN_LIST}
    VALID_DOC_TYPE_INDIC = {e for e in _OECD_DOC_TYPE}
    VALID_COUNTRY_CODES = {e.value for e in CountryCodeType}
    VALID_CURRENCY_CODES = {e.value for e in CurrCodeType}
    VALID_MSG_TYPE_INDIC = {e.value for e in CrsMessageTypeIndicEnumType}
    VALID_ENTITY_ID_TYPE = {e for e in _ENTITY_ID_TYPE}
    VALID_ACCT_HOLDER_TYPE = {e for e in _ACCT_HOLDER_TYPE}
    VALID_MESSAGE_TYPE_INDIC = {e for e in _MESSAGE_TYPE_INDIC}

    # -- Cols for checks
    VALIDATE_MSG_HEADER_COUNTRIES = [
        COL_TRANSMITTINGCOUNTRY,
        COL_RECEIVINGCOUNTRY,
    ]
