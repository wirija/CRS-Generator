from __future__ import annotations

import shutil
from pathlib import Path

import pandas as pd
from openpyxl import load_workbook
from openpyxl.utils.dataframe import dataframe_to_rows

from src.crs2.excel_validator.validation_config import SHEET_RULES, SHEET_REPORTABLE_JURISDICTION
from src.crs2.excel_validator.validation_dispatcher import apply_rule
from src.crs2.excel_validator.validation_rules import _ensure_check_columns
from src.crs2.read_excel import SHEETS_TO_READ
from src.crs2.read_excel_const import CONST

DEBUGMODE = False


# -----------------------------------
# HELPERS: CLEAR VALUES, KEEP FORMAT
# -----------------------------------
def _clear_values(
    ws,
    *,
    keep_header_row: bool = True,
) -> None:
    """
    Clears cell VALUES (not styles) within the worksheet's used range.
    If keep_header_row=True, row 1 values are preserved.
    """
    min_row = 2 if keep_header_row else 1
    max_row = ws.max_row or 1
    max_col = ws.max_column or 1

    for row in ws.iter_rows(
        min_row=min_row, max_row=max_row, min_col=1, max_col=max_col
    ):
        for cell in row:
            cell.value = None


def _write_df_keep_format(
    ws,
    df: pd.DataFrame,
    *,
    start_row: int = 1,
    start_col: int = 1,
    write_header: bool = True,
    template_style_row: int | None = 2,
) -> None:
    """
    Writes df values into ws starting at (start_row, start_col).

    - If cells already exist with formatting, formatting is preserved.
    - If df extends beyond formatted template rows, optionally extend formatting
      by copying styles from template_style_row downwards.
    """
    if template_style_row is not None:
        _extend_row_styles(
            ws,
            template_style_row=template_style_row,
            start_row=start_row,
            start_col=start_col,
            ncols=df.shape[1],
            nrows=len(df),
            write_header=write_header,
        )

    for r_idx, row in enumerate(
        dataframe_to_rows(df, index=False, header=write_header), start=start_row
    ):
        for c_idx, value in enumerate(row, start=start_col):
            ws.cell(row=r_idx, column=c_idx).value = value


def _extend_row_styles(
    ws,
    *,
    template_style_row: int,
    start_row: int,
    start_col: int,
    ncols: int,
    nrows: int,
    write_header: bool,
) -> None:
    """
    If df needs more rows than currently exist / are styled, copy styles from
    template_style_row into additional rows across the columns being written.

    This is OPTIONAL but helps when DF grows beyond your preformatted template area.
    """
    header_offset = 0 if write_header else 1
    needed_last_row = start_row + header_offset + nrows - 1
    existing_last_row = ws.max_row or 1

    if needed_last_row <= existing_last_row:
        return

    for r in range(existing_last_row + 1, needed_last_row + 1):
        for c in range(start_col, start_col + ncols):
            src = ws.cell(row=template_style_row, column=c)
            dst = ws.cell(row=r, column=c)

            # Copy style-ish attributes (openpyxl style objects are immutable-ish but assignable)
            if src.has_style:
                dst._style = src._style

            dst.number_format = src.number_format
            dst.font = src.font
            dst.border = src.border
            dst.fill = src.fill
            dst.alignment = src.alignment
            dst.protection = src.protection


def _update_df_columns(df:pd.DataFrame) -> pd.DataFrame:
    df[CONST.COL_CHECK_REPORTABLE] = True
    df[CONST.COL_CHECK_ERROR] = ""
    df[CONST.COL_CHECK_WARNING] = ""

    return df

# def validate_sheets(
#     dfs: dict[str, pd.DataFrame],
#     outpath: str | Path | None = None,
# ) -> dict[str, pd.DataFrame]:
#     """Validate all required sheets and optionally write the validated output to Excel."""
#     missing_sheets = [sheet for sheet in SHEETS_TO_READ if sheet not in dfs]           # Compare expected sheet names against provided keys
#     if missing_sheets:
#         raise KeyError(f"Missing required sheets: {missing_sheets}")

#     validated_dfs = {}                                                                 # Store validated output by sheet name

#     for sheet_name, df in dfs.items():
#         if sheet_name in SHEET_RULES:
#             validated_dfs[sheet_name] = validate_sheet(df, sheet_name)                 # Validate only sheets that have a configured rule set
#         else:
#             untouched_df = df.copy()                                                   # Preserve sheets with no configured validation rules
#             untouched_df = _ensure_check_columns(untouched_df)
#             validated_dfs[sheet_name] = untouched_df

#     if outpath is not None:
#         outpath = Path(outpath)                                                        # Accept either str or Path as input
#         outpath.parent.mkdir(parents=True, exist_ok=True)                              # Create parent folder when needed

#         with pd.ExcelWriter(outpath, engine="openpyxl") as writer:
#             for sheet_name, df in validated_dfs.items():
#                 df.to_excel(writer, sheet_name=sheet_name, index=False)                # Write each validated DataFrame back to Excel

#     return validated_dfs


def validate_sheets(
    dfs: dict[str, pd.DataFrame],
    reportable_jurisdiction: list[str]
) -> dict[str, pd.DataFrame]:
    """Validate all required sheets using configured rules."""
    missing_sheets = [sheet for sheet in SHEETS_TO_READ if sheet not in dfs]
    if missing_sheets:
        raise KeyError(f"Missing required sheets: {missing_sheets}")

    validated_dfs: dict[str, pd.DataFrame] = {}

    for sheet_name, df in dfs.items():
        working_df = df.copy()
        working_df = _ensure_check_columns(working_df)

        if sheet_name in SHEET_RULES:

            for rule in SHEET_RULES[sheet_name]:
                if DEBUGMODE:
                    print(f" -- Checking Sheet - [{sheet_name}]")
                    temp = rule
                    print(f" ----- The columns for these checks are \n [{temp}]")
                    print(f"\n")
                working_df = apply_rule(working_df, rule)


            # Get from Config - on reportable jurisdiction check
            
        if sheet_name in SHEET_REPORTABLE_JURISDICTION:
            masks = []

            for col in SHEET_REPORTABLE_JURISDICTION[sheet_name]["cols"]:
                mask = (
                    df[col]
                    .astype("string")
                    .str.strip()
                    .str.upper()
                    .isin(reportable_jurisdiction)
                    .fillna(False)
                )
                masks.append(mask)

            working_df[CONST.COL_CHECK_REPORTABLE] = pd.concat(masks, axis=1).any(axis=1)

        validated_dfs[sheet_name] = working_df

    return validated_dfs


def _validation_results(validated_dfs: dict[str, pd.DataFrame]) -> str:

    rows = []

    for sheet_name, df in validated_dfs.items():

        if sheet_name in SHEET_RULES:
            error_count = (
                df[CONST.COL_CHECK_ERROR]
                .astype("string")
                .fillna("")
                .str.strip()
                .ne("")
                .sum()
            )

            warning_count = (
                df[CONST.COL_CHECK_WARNING]
                .astype("string")
                .fillna("")
                .str.strip()
                .ne("")
                .sum()
            )

            
            non_reportable_count = (
                df[CONST.COL_CHECK_REPORTABLE]
                .fillna(False)
                .eq(False)
                .sum()
            )
            
            rows.append(
                        {
                            "Sheet Name": sheet_name,
                            "Total Rows": len(df),
                            "Errors (rows)": int(error_count),
                            "Warnings (rows)": int(warning_count),
                            "Non-Reportable (rows)": int(non_reportable_count),
                        }
                    )

    return pd.DataFrame(rows)




# -----------------------------
# MAIN WORKBOOK-LEVEL FUNCTION
# -----------------------------
def excel_validator(
    inpath: str | Path,
    outpath: str | Path,
    *,
    keep_header_row: bool = True,
    start_row: int = 1,
    start_col: int = 1,
    write_header: bool = True,
    template_style_row: (
        int | None
    ) = 2,  # row used as style template for data rows (optional)
    keep_vba: bool = False,  # set True if input/output is .xlsm and you want to preserve macros
) -> dict[str, pd.DataFrame]:
    """
    Validate an Excel workbook while preserving original formatting in the output copy.

    Steps:
      1) Copy original workbook to outpath (format preserved)
      2) Read original workbook values into DataFrames
      3) Validate via validate_sheets()
      4) Write validated values back into copied workbook (keep formatting)

    Returns:
      validated_dfs: dict of sheet_name -> validated DataFrame
    """
    inpath = Path(inpath)
    outpath = Path(outpath)
    outpath.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    # 1) Copy the original file (preserves ALL formatting in the copy)
    shutil.copy2(inpath, outpath)

    # 2) Read values into DataFrames for validation
    dfs = pd.read_excel(
        inpath,
        sheet_name=None,
        engine="openpyxl",
        dtype=str,
    )

    
    dfs = {
        sheet: df.astype("string").fillna("")
        for sheet, df in dfs.items()
    }

    dfs = {
        sheet: _update_df_columns(df)
        for sheet, df in dfs.items()
    }


    if DEBUGMODE:
        for sheet_name, df in dfs.items():
            print (f"sheet = {sheet_name}")
            print ( "----------------------------")
            print (df)
            print ("\n")

    reportable_jurisdiction = dfs[CONST.SHEET_REPORTABLE_JURISDICTION].iloc[:, 0].astype("string").str.upper().tolist()

    # 3) Validate using your existing rules (DO NOT write with pandas)
    validated_dfs = validate_sheets(dfs, reportable_jurisdiction)
    # validated_dfs=dfs # for DEBUG

    # 4) Open copied workbook and write back values while preserving formatting
    wb = load_workbook(
        outpath,
        keep_vba=keep_vba,
    )

    for sheet_name, vdf in validated_dfs.items():
        # Only overwrite sheets "being reviewed" (i.e., those with rules)
        if sheet_name not in SHEET_RULES:
            continue

        if sheet_name not in wb.sheetnames:
            continue

        ws = wb[sheet_name]

        # 2a/2b) Keep formatting; clear data (values only)
        _clear_values(
            ws,
            keep_header_row=keep_header_row,
        )

        # 2c) Write validated DF values back into sheet
        _write_df_keep_format(
            ws,
            vdf,
            start_row=start_row,
            start_col=start_col,
            write_header=write_header,
            template_style_row=template_style_row,
        )

    wb.save(outpath)

    print("\n")
    print(_validation_results(validated_dfs=validated_dfs).to_markdown(index=False))
    print("\n")
    
    return validated_dfs, 
