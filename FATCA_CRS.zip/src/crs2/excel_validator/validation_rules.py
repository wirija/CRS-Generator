from __future__ import annotations

from typing import Iterable, Mapping, Sequence

import pandas as pd

from src.crs2.read_excel_const import CONST


def _require_columns(df: pd.DataFrame, cols: Iterable[str]) -> None:
    """Raise a KeyError if any required columns are missing from the DataFrame."""
    missing_cols = [col for col in cols if col not in df.columns]                     # Collect only truly missing columns
    if missing_cols:
        raise KeyError(f"Missing required columns: {missing_cols}")                    # Fail early with a precise message


def _ensure_check_columns(df: pd.DataFrame) -> pd.DataFrame:
    """Ensure validation output columns exist on the DataFrame."""
    if CONST.COL_CHECK_ERROR not in df.columns:
        df[CONST.COL_CHECK_ERROR] = ""                                                 # Store validation error text here

    if CONST.COL_CHECK_REPORTABLE not in df.columns:
        df[CONST.COL_CHECK_REPORTABLE] = ""                                            # Store TRUE / FALSE reportable flag here

    return df


def _normalize_series(df: pd.DataFrame, col: str, upper: bool = False) -> pd.Series:
    """Return a normalized string series: StringDtype, stripped, and optionally uppercased."""
    s = df[col].astype("string").str.strip()                                           # Normalize type and trim surrounding whitespace
    if upper:
        s = s.str.upper()                                                               # Standardize case when matching codes / enums
    return s


def _append_error_warning(
    df: pd.DataFrame,
    invalid_mask: pd.Series,
    message: str,
    error: bool = True,
) -> pd.DataFrame:
    """Append an error message to rows where invalid_mask is True."""
    df = _ensure_check_columns(df)                                                     # Ensure destination column exists first
    invalid_mask = invalid_mask.fillna(False)                                           # Treat missing mask values as not-selected

    col_update = CONST.COL_CHECK_ERROR if error else CONST.COL_CHECK_WARNING

    df.loc[invalid_mask, col_update] = (
        df.loc[invalid_mask, col_update]
        .astype("string")
        .fillna("")
        + message
    )                                                                                   # Append instead of overwrite, so multiple errors accumulate

    return df


def check_single_row(df: pd.DataFrame) -> pd.DataFrame:
    """Append a sheet-level error if the DataFrame contains more than one row."""
    df = _ensure_check_columns(df)                                                     # Ensure error column exists before writing

    if len(df) > 1:
        df.loc[:, CONST.COL_CHECK_ERROR] = (
            df[CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + "There should only be 1 line for this sheet; \n"
        )                                                                               # Add the same sheet-level error to all rows

    return df


def check_allowed_values(
    df: pd.DataFrame,
    cols: Sequence[str],
    valid_values: Sequence[str] | set[str],
    message_template: str,
    *,
    upper: bool = True,
    allow_blank: bool = False,
) -> pd.DataFrame:
    """
    Validate that each specified column contains a value from a permitted list.

    Parameters
    ----------
    df:
        Source DataFrame.
    cols:
        Columns to validate.
    valid_values:
        Allowed values for the field.
    message_template:
        Error message template. Use {col} if you want the column name inserted.
    upper:
        If True, normalize values to upper case before comparison.
    allow_blank:
        If True, blank values are treated as valid.
    """
    _require_columns(df, cols)

    valid_values_set = {str(v).upper() if upper else str(v) for v in valid_values}     # Normalize allowed values once, outside the loop

    for col in cols:
        s = _normalize_series(df, col, upper=upper)                                     # Normalize the input column consistently
        is_blank = (s.isna() | s.eq("")).fillna(True)                                   # Treat NA and "" as blank
        is_valid = s.isin(valid_values_set).fillna(False)                               # Check membership against standardized set

        invalid_mask = ~is_valid if not allow_blank else ~(is_valid | is_blank)         # Optionally let blanks pass validation
        message = message_template.format(col=col)                                       # Insert column name into error message

        df = _append_error_warning(df, invalid_mask, message)

    return df


def check_blank(
    df: pd.DataFrame,
    cols_blank: Sequence[str],
) -> pd.DataFrame:
    """Validate that each specified column is blank."""
    _require_columns(df, cols_blank)

    for col in cols_blank:
        s = _normalize_series(df, col, upper=False)                                     # Preserve original case; only trim whitespace
        invalid_mask = ~(s.isna() | s.eq("")).fillna(False)                             # Invalid when there is any non-blank content

        df = _append_error_warning(
            df,
            invalid_mask,
            f"Error at column [{col}] - the entry value should be empty; \n",
        )

    return df


def check_fixed_value(
    df: pd.DataFrame,
    cols_fixed_value: Sequence[str],
    value: str,
) -> pd.DataFrame:
    """Validate that each specified column equals one fixed value."""
    _require_columns(df, cols_fixed_value)

    expected_value = value.upper()                                                      # Compare in uppercase for consistency

    for col in cols_fixed_value:
        s = _normalize_series(df, col, upper=True)                                      # Normalize to uppercase before comparison
        invalid_mask = ~s.eq(expected_value).fillna(False)                              # Invalid when not exactly equal to expected value

        df = _append_error_warning(
            df,
            invalid_mask,
            f"Error at column [{col}] - the entry value should be {expected_value}; \n",
        )

    return df


def check_numeric_2dp(
    df: pd.DataFrame,
    cols_numeric: Sequence[str],
    *,
    allow_blank: bool = False,
) -> pd.DataFrame:
    """Validate that each specified column contains a numeric value with exactly 2 decimal places."""
    _require_columns(df, cols_numeric)

    pattern = r"\d+\.\d{2}"                                                             # Examples: 10.00, 0.50, 123456.78

    for col in cols_numeric:
        s = _normalize_series(df, col, upper=False)                                     # Numeric string validation does not need uppercasing
        is_blank = (s.isna() | s.eq("")).fillna(True)                                   # Support optional numeric fields if required
        is_valid = s.str.fullmatch(pattern).fillna(False)                               # Must fully match the pattern, not partially match

        invalid_mask = ~is_valid if not allow_blank else ~(is_valid | is_blank)         # Allow blanks only when explicitly requested

        df = _append_error_warning(
            df,
            invalid_mask,
            f"Error at column [{col}] - numeric values should have exactly 2 decimal places; \n",
        )

    return df


def check_fixed_length(
    df: pd.DataFrame,
    col_lengths: Mapping[str, Mapping[str, int | bool]],
) -> pd.DataFrame:
    """
    Validate that column values fall within configured length ranges.

    Each entry in col_lengths should look like:
        {
            "Some Column": {"min": 1, "max": 10, "allow_blank": False}
        }

    If allow_blank is omitted, it defaults to True when min == 0, otherwise False.
    """
    _require_columns(df, col_lengths.keys())

    for col, rules in col_lengths.items():
        min_len = int(rules.get("min", 0))                                              # Minimum permitted length
        max_len = int(rules.get("max", min_len))                                        # Maximum permitted length, defaulting to min
        allow_blank = bool(rules.get("allow_blank", min_len == 0))                      # Optional fields usually have min == 0

        s = _normalize_series(df, col, upper=False)                                     # Length checks do not require case normalization
        is_blank = (s.isna() | s.eq("")).fillna(True)                                   # Blank means NA, empty, or whitespace-only
        length = s.str.len()                                                            # Compute per-row string length after trimming
        len_invalid = (length.lt(min_len) | length.gt(max_len)).fillna(True)            # Invalid when outside configured range

        invalid_mask = len_invalid if not allow_blank else (~is_blank & len_invalid)    # Ignore blanks only when blanks are permitted
        invalid_mask = invalid_mask | (is_blank & (not allow_blank))                         # Blank is invalid when blank values are not allowed

        if min_len == max_len:
            message = f"Error at column [{col}] - value must be exactly {min_len} characters; \n"
        else:
            message = f"Error at column [{col}] - value must be between {min_len} and {max_len} characters; \n"

        df = _append_error_warning(df, invalid_mask, message)

    return df


def check_org_in(
    df: pd.DataFrame,
    cols_in: Sequence[str],
) -> pd.DataFrame:
    """
    Validate organizational IN fields.

    Expected structure:
        <ENTITY_ID_TYPE> <ENTITY_ID>

    Example:
        'UEN-BUSINESS 201912345Z'

    Validation rules:
    - Entity ID Type = all tokens except the last token
    - Entity ID      = the last token
    - Entity ID Type must be in CONST.VALID_ENTITY_ID_TYPE
    - Entity ID must be exactly 10 characters
    """
    _require_columns(df, cols_in)

    valid_types = {str(v).upper() for v in CONST.VALID_ENTITY_ID_TYPE}                  # Normalize once for comparison
    valid_types_text = ", ".join(sorted(valid_types))                                   # Build user-facing text only once

    for col in cols_in:
        s = _normalize_series(df, col, upper=True)                                      # Standardize input before splitting
        tokens = s.str.split()                                                          # Split on any whitespace
        entity_id_type = tokens.str[:-1].str.join(" ")                                  # All tokens except the last
        entity_id = tokens.str[-1]                                                      # Last token only

        is_blank = (s.isna() | s.eq("")).fillna(True)                                   # Blank values are invalid for this field
        bad_type = (~entity_id_type.isin(valid_types)).fillna(True)                     # Missing / unknown entity type is invalid
        bad_length = entity_id.astype("string").str.len().ne(10).fillna(True)           # Entity ID must be exactly 10 characters

        invalid_mask = (is_blank | bad_type | bad_length).fillna(True)                  # Any failure makes the row invalid

        df = _append_error_warning(
            df,
            invalid_mask,
            f"Error at column [{col}] - Invalid Entity ID Type or Entity ID length. "
            f"Valid types: [{valid_types_text}]. Entity ID must be exactly 10 characters; \n",
        )

    return df




def check_name(
    df: pd.DataFrame,
    cols_names: Sequence[str],
) -> pd.DataFrame:
    """
    Validate name fields.

    Flags a row as invalid if:
      - First name is blank, OR
      - First name is 'NFN' (No First Name) AND last name is blank.

    Notes:
      - Values are normalized via: string -> strip -> upper -> NA->"".
      - Middle name is not required (i.e., can be blank).
    """

    if len(cols_names) != 3: raise ValueError("Columns need to have at least 3 items") 

    col_first_name, col_middle_name, col_last_name  = cols_names[0:3]
    _require_columns(df, [col_first_name, col_middle_name, col_last_name])

    # Normalize to trimmed uppercase strings; replace <NA> with ""
    s_first  = (
        df[col_first_name]
        .astype("string")
        .str.strip()
        .str.upper()
        .fillna("")
    )
    s_middle = (
        df[col_middle_name]
        .astype("string")
        .str.strip()
        .str.upper()
        .fillna("")
    )
    s_last   = (
        df[col_last_name]
        .astype("string")
        .str.strip()
        .str.upper()
        .fillna("")
    )

    # Emptiness checks (no NA possible after fillna(""))
    first_empty  = s_first.eq("")
    last_empty   = s_last.eq("")

    # Rule checks
    first_name_blank = first_empty
    first_name_NFN_last_name_blank = s_first.eq("NFN") & last_empty

    # Final invalid mask
    invalid_mask = first_name_blank | first_name_NFN_last_name_blank

    df = _append_error_warning(
        df,
        invalid_mask,
        (
            f"Error at columns [{col_first_name}], [{col_middle_name}], [{col_last_name}] - "
            f"Invalid name: First name is blank, or First name is 'NFN' with blank last name.\n"
        ),
    )
    return df



def check_birthdates(
    df: pd.DataFrame,
    cols_birthdates: Sequence[str],
) -> pd.DataFrame:
    """
    Validate birthdate fields.

    Validation rules:
    - Blank values are allowed
    - Non-blank values must be:
        - A valid date
        - Not in the future
        - Not unreasonably old (>120 years ago)
    """
    _require_columns(df, cols_birthdates)

    today = pd.Timestamp.today().normalize()
    too_old_cutoff = today - pd.DateOffset(years=120)

    for col in cols_birthdates:
        s = _normalize_series(df, col, upper=False)                        # Keep original case for dates

        is_blank = (s.isna() | s.eq("")).fillna(True)                      # Blank values are allowed

        parsed = pd.to_datetime(s, errors="coerce")

        bad_format = (~is_blank & parsed.isna()).fillna(False)            # Non-blank but unparsable
        in_future = (~is_blank & parsed.gt(today)).fillna(False)          # Birthdate in the future
        too_old = (~is_blank & parsed.lt(too_old_cutoff)).fillna(False)   # Implausibly old birthdate

        invalid_mask = (bad_format | in_future | too_old).fillna(False)

        df = _append_error_warning(
            df,
            invalid_mask,
            f"Error at column [{col}] - Invalid birthdate. "
            f"Date must be valid, not in the future, and not earlier than "
            f"{too_old_cutoff.date()}; \n",
        )

    return df


def warning_TIN_wo_city(
    df: pd.DataFrame,
    cols_TIN_city: Sequence[str],
) -> bool:
    col_TIN, col_city = cols_TIN_city[0], cols_TIN_city[1]

    s_tin = df[col_TIN].astype("string").str.strip().str.upper()
    s_city = df[col_city].astype("string").str.strip()

    tin_is_valid_or_empty = s_tin.isin(CONST.VALID_IN) | s_tin.isna() | s_tin.eq("")
    city_is_empty = s_city.isna() | s_city.eq("")


    invalid_mask = (tin_is_valid_or_empty & city_is_empty).fillna(False)

    df = _append_error_warning(
            df,
            invalid_mask,
            f"Warning at columns [{col_TIN}], [{col_city}] - Missing city where TIN is missing; city is recommended.",
            error=False,
            )
    
    return df



