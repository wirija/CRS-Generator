from __future__ import annotations
from src.crs2.read_excel_const import CONST

SHEET_RULES = {
    CONST.SHEET_MSG_HEADER: [
        {"type": "single_row"},                                                   # Sheet-level check: exactly one row expected
        {
            "type": "org_in",
            "cols": [CONST.COL_SENDINGCOMPANYIN],
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_TRANSMITTINGCOUNTRY, CONST.COL_RECEIVINGCOUNTRY],
            "valid_values": CONST.VALID_COUNTRY_CODES,
            "message": "Error at column [{col}] - Invalid country code. Must be from the standard ISO country code list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "fixed_value",
            "cols": [CONST.COL_MESSAGETYPE],
            "value": "CRS",
        },
        {
            "type": "blank",
            "cols": [CONST.COL_WARNING, CONST.COL_CONTACT],
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_MESSAGETYPEINDIC],
            "valid_values": CONST.VALID_MESSAGE_TYPE_INDIC,
            "message": "Error at column [{col}] - Invalid MessageTypeIndic. Must be from the permitted list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "fixed_length",
            "col_lengths": {
                CONST.COL_MESSAGEREFID: {"min": 10, "max": 10, "allow_blank": False},
            },
        },
    ],

    CONST.SHEET_REPORTING_FI: [
        {"type": "single_row"},
        {
            "type": "org_in",
            "cols": [CONST.COL_IN],
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_DOCTYPEINDIC],
            "valid_values": CONST.VALID_DOC_TYPE_INDIC,
            "message": "Error at column [{col}] - Doc Type Indic must be from the permitted list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE],
            "valid_values": CONST.VALID_COUNTRY_CODES,
            "message": "Error at column [{col}] - Invalid country code. Must be from the standard ISO country code list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "fixed_length",
            "col_lengths": {
                CONST.COL_DOCREFID: {"min": 10, "max": 10, "allow_blank": False},
                CONST.COL_NAME: {"min": 1, "max": 200, "allow_blank": False},
                CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000, "allow_blank": False},
                CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200, "allow_blank": True},
            },
        },
    ],

    CONST.SHEET_REPORTABLE_ORG_ACC: [
        # {
        #     "type": "allowed_values",
        #     "cols": [CONST.COL_IN],
        #     "valid_values": CONST.VALID_IN,
        #     "message": "Error at column [{col}] - Invalid IN value. Must be from the permitted standard list; \n",
        #     "upper": True,
        #     "allow_blank": False,
        # },
        {
            "type": "numeric_2dp",
            "cols": [
                CONST.COL_ACCOUNT_BALANCE,
                CONST.COL_DIVIDENDS_PAYMENT_AMOUNT,
                CONST.COL_INTEREST_PAYMENT_AMOUNT,
                CONST.COL_GROSS_PROCEEDS_PAYMENT_AMOUNT,
                CONST.COL_OTHER_PAYMENT_AMOUNT,
            ],
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [
                CONST.COL_CURRCODE,
                CONST.COL_DIVIDENDS_PAYMENT_CURRCODE,
                CONST.COL_INTEREST_PAYMENT_CURRCODE,
                CONST.COL_GROSS_PROCEEDS_PAYMENT_CURRCODE,
                CONST.COL_OTHER_PAYMENT_CURRCODE,
            ],
            "valid_values": CONST.VALID_CURRENCY_CODES,
            "message": "Error at column [{col}] - Invalid currency code. Must be an ISO 4217 three-letter code from the standard list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_DOCTYPEINDIC],
            "valid_values": CONST.VALID_DOC_TYPE_INDIC,
            "message": "Error at column [{col}] - Doc Type Indic must be from the permitted list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE],
            "valid_values": CONST.VALID_COUNTRY_CODES,
            "message": "Error at column [{col}] - Invalid country code. Must be from the standard ISO country code list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_ACCTHOLDERTYPE],
            "valid_values": CONST.VALID_ACCT_HOLDER_TYPE,
            "message": "Error at column [{col}] - Invalid account holder type. Must be from the permitted standard list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_ACCOUNT_CLOSED],
            "valid_values": {"TRUE", "FALSE"},
            "message": "Error at column [{col}] - value must be either TRUE or FALSE; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "fixed_length",
            "col_lengths": {
                CONST.COL_DOCREFID: {"min": 10, "max": 10, "allow_blank": True},
                CONST.COL_NAME: {"min": 1, "max": 200, "allow_blank": True},
                CONST.COL_IN: {"min": 1, "max": 200, "allow_blank": False},
                CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000, "allow_blank": True},
                CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200, "allow_blank": True},
            },
        },
    ],

    CONST.SHEET_REPORTABLE_INDIV_ACC:[
         {
            "type": "allowed_values",
            "cols": [CONST.COL_DOCTYPEINDIC],
            "valid_values": CONST.VALID_DOC_TYPE_INDIC,
            "message": "Error at column [{col}] - Doc Type Indic must be from the permitted list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE, CONST.COL_TIN_ISSUED_BY],
            "valid_values": CONST.VALID_COUNTRY_CODES,
            "message": "Error at column [{col}] - Invalid country code. Must be from the standard ISO country code list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "allowed_values",
            "cols": [
                CONST.COL_CURRCODE,
                CONST.COL_DIVIDENDS_PAYMENT_CURRCODE,
                CONST.COL_INTEREST_PAYMENT_CURRCODE,
                CONST.COL_GROSS_PROCEEDS_PAYMENT_CURRCODE,
                CONST.COL_OTHER_PAYMENT_CURRCODE,
            ],
            "valid_values": CONST.VALID_CURRENCY_CODES,
            "message": "Error at column [{col}] - Invalid currency code. Must be an ISO 4217 three-letter code from the standard list; \n",
            "upper": True,
            "allow_blank": False,
        },
        {
            "type": "numeric_2dp",
            "cols": [
                CONST.COL_ACCOUNT_BALANCE,
                CONST.COL_DIVIDENDS_PAYMENT_AMOUNT,
                CONST.COL_INTEREST_PAYMENT_AMOUNT,
                CONST.COL_GROSS_PROCEEDS_PAYMENT_AMOUNT,
                CONST.COL_OTHER_PAYMENT_AMOUNT,
            ],
            "allow_blank": False,
        }, 
        # {
        #     "type": "allowed_values",
        #     "cols": [CONST.COL_TIN],
        #     "valid_values": CONST.VALID_IN,
        #     "message": "Error at column [{col}] - Invalid IN value. Must be from the permitted standard list; \n",
        #     "upper": True,
        #     "allow_blank": False,
        # },
        {
            "type": "check_names",
            "cols": [CONST.COL_FIRST_NAME, CONST.COL_MIDDLE_NAME, CONST.COL_LAST_NAME],
        },
        {
            "type": "check_birthdates",
            "cols": [CONST.COL_BIRTHDATE],
        },
        {
            "type": "fixed_length",
            "col_lengths": {
                CONST.COL_TIN: {"min": 1, "max": 20, "allow_blank": False},
                CONST.COL_ACCOUNTNUMBER: {"min": 1, "max": 200, "allow_blank": False},
                CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000, "allow_blank": False},
                CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200, "allow_blank": True},
            },
        },
        {
            "type": "warning_missing_TIN_city",
            "cols": [CONST.COL_TIN, CONST.COL_ADDRESSFIX_CITY]
        },

    ],
    CONST.SHEET_CONTROLLING_PERSON:[
        {
            "type": "allowed_values",
            "cols": [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE, CONST.COL_TIN_ISSUED_BY],
            "valid_values": CONST.VALID_COUNTRY_CODES,
            "message": "Error at column [{col}] - Invalid country code. Must be from the standard ISO country code list; \n",
            "upper": True,
            "allow_blank": False,
        },
        # {
        #     "type": "allowed_values",
        #     "cols": [CONST.COL_TIN],
        #     "valid_values": CONST.VALID_IN,
        #     "message": "Error at column [{col}] - Invalid IN value. Must be from the permitted standard list; \n",
        #     "upper": True,
        #     "allow_blank": False,
        # },
        {
            "type": "check_names",
            "cols": [CONST.COL_FIRST_NAME, CONST.COL_MIDDLE_NAME, CONST.COL_LAST_NAME],
        },
        {
            "type": "check_birthdates",
            "cols": [CONST.COL_BIRTHDATE],
        },
        {
            "type": "fixed_length",
            "col_lengths": {
                CONST.COL_TIN: {"min": 1, "max": 20, "allow_blank": False},
                CONST.COL_ACCOUNTNUMBER: {"min": 1, "max": 200, "allow_blank": False},
                CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000, "allow_blank": False},
                CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200, "allow_blank": True},
                CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200, "allow_blank": True},
            },
        },
        {
            "type": "warning_missing_TIN_city",
            "cols": [CONST.COL_TIN, CONST.COL_ADDRESSFIX_CITY]
        }

    ],
}


SHEET_REPORTABLE_JURISDICTION ={
    CONST.SHEET_REPORTABLE_ORG_ACC :{'cols':[CONST.COL_RESCOUNTRYCODE, CONST.COL_IN_ISSUED_BY, CONST.COL_COUNTRYCODE]},
    CONST.SHEET_REPORTABLE_INDV_ACC :{'cols':[CONST.COL_RESCOUNTRYCODE, CONST.COL_TIN_ISSUED_BY, CONST.COL_COUNTRYCODE]},
    CONST.SHEET_CONTROLLING_PERSON :{'cols':[CONST.COL_RESCOUNTRYCODE, CONST.COL_TIN_ISSUED_BY, CONST.COL_COUNTRYCODE]},
}