import os, math
from pathlib import Path
import pandas as pd
from src.CRS_2.read_excel_const import CONST as CONST
import numpy as np
from xsdata.models.datatype import XmlDate, XmlDateTime
from pathlib import Path
from datetime import datetime
from xsdata.formats.dataclass.serializers import XmlSerializer
from xsdata.formats.dataclass.serializers.config import SerializerConfig
from read_excel import SHEETS_TO_READ


def _check_numeric(
    df: pd.DataFrame,
    cols_numeric: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_numeric]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_numeric:
        s = df[col].astype("string").str.strip()

        pattern = r"\d+\.\d{2}"

        invalid_mask = ~(
            df[col].astype("string").str.strip().str.fullmatch(pattern).fillna(False)
        )
        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - numeric values should have 2 decimal places; \n"
        )
    return df


def _check_country(
    df: pd.DataFrame,
    cols_country: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_country]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_country:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_COUNTRY_CODES)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Country code has to be from standard list; \n"
        )

    return df


def _check_IN(
    df: pd.DataFrame,
    cols_IN: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_IN]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_IN:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_IN)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - – Invalid country code. Must be an ISO‑3166 Alpha‑2 code from the standard list; \n"
        )

    return df


def _check_doc_type_indic(
    df: pd.DataFrame,
    cols_DocTypeIndic: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_DocTypeIndic]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_DocTypeIndic:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_IN)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Doc Type indicator should be OECD1, OECD2, or OECD3 ; \n"
        )

    return df


def _check_currency_code(
    df: pd.DataFrame,
    cols_currency_code: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_currency_code]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_currency_code:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_CURRENCY_CODES)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Invalid currency code. Must be ISO 4217 three-byte alpha from the standard list; \n"
        )

    return df


def _check_msgTypeIndic(
    df: pd.DataFrame,
    cols_messageType: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_messageType]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_messageType:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_CURRENCY_CODES)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Invalid currency code. Must be ISO 4217 three-byte alpha from the standard list; \n"
        )

    return df


def _check_blank(
    df: pd.DataFrame,
    cols_messageType: list,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_messageType]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_messageType:
        df[col] = df[col].str.upper()
        s = df[col].astype("string").str.strip()  # normalize to string + trim spaces

        invalid_mask = ~(s.isna() | s.eq("")).fillna(False)  # True if empty (NA or "")

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - the entry value should be empty; \n"
        )

    return df


def _check_fixed_value(
    df: pd.DataFrame,
    cols_fixed_value: list,
    value: str,
) -> pd.DataFrame:

    # check if columns exists
    missing = [col not in df.columns for col in cols_fixed_value]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    value = value.upper()

    for col in cols_fixed_value:
        df[col] = df[col].str.upper()
        s = df[col].astype("string").str.strip()  # normalize to string + trim spaces

        invalid_mask = ~s.eq(value).fillna(False)  # True if not a fixed value

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - the entry value should be {value}; \n"
        )

    return df


def _check_org_IN(
    df: pd.DataFrame,
    cols_IN: list | None = None,
) -> pd.DataFrame:
    """
    Validate that the Entity ID Type portion of SendingCompanyIN is in CONST.VALID_ENTITY_ID_TYPE.
    The Entity ID Type is defined as: all whitespace-separated tokens except the last token.
    Example: "UEN-Business 201912345Z" -> Entity ID Type = "UEN-Business"
    """

    # default to checking the SendingCompanyIN column if caller doesn't specify
    cols_to_check = cols_IN

    # 1) ensure required columns exist
    missing = [c for c in cols_to_check if c not in df.columns]
    if missing:
        raise KeyError(f"Missing required columns: {missing}")

    valid_types = set(CONST.VALID_ENTITY_ID_TYPE)
    valid_types_txt = ", ".join(sorted(valid_types))

    for col in cols_to_check:
        s = df[col].astype("string").str.strip().str.upper()

        # entity_ID_type = all tokens except last, joined back with spaces
        entity_ID_type = (
            s.str.split()  # split on any whitespace
            .str[:-1]  # keep all tokens except the last
            .str.join(" ")  # join back into a single string
        )

        entity_ID = s.str.split().str[-1]

        entity_ID_len_invalid = entity_ID.astype("string").str.len().ne(10).fillna(True)

        # invalid if non-empty but type not in allowed list
        is_empty = (s.isna() | s.eq("")).fillna(False)
        bad_type = (~entity_ID_type.isin(valid_types)).fillna(True)
        bad_len = entity_ID_len_invalid  # already boolean with NA handled

        invalid_mask = (is_empty | bad_type | bad_len).fillna(True)

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Invalid Entity ID Type. Valid types: [{valid_types_txt}].\n"
        )

    return df


def _check_fixed_length(df: pd.DataFrame, col_length: dict) -> pd.DataFrame:
    """
    Check that each specified column's values have length within [min, max].
    Empty (NA / "" / whitespace-only) values are treated as INVALID.
    Appends error messages into CONST.COL_CHECK_ERROR.
    """

    # 1) ensure required columns exist
    missing_cols = [c for c in col_length.keys() if c not in df.columns]
    if missing_cols:
        raise KeyError(f"Missing required columns: {missing_cols}")

    # 2) ensure error column exists (create if missing)
    if CONST.COL_CHECK_ERROR not in df.columns:
        df[CONST.COL_CHECK_ERROR] = ""

    # 3) validate each column
    for col, rules in col_length.items():
        min_len = int(rules.get("min", 0))  # minimum allowed length
        max_len = int(rules.get("max", min_len))  # maximum allowed length (default=min)

        s = df[col].astype("string").str.strip()  # normalize to string + trim spaces
        is_empty = (s.isna() | s.eq("")).fillna(
            True
        )  # True if empty (NA or "" after trim)

        length = s.str.len()  # per-row string length (NA -> <NA>)
        len_invalid = (length.lt(min_len) | length.gt(max_len)).fillna(
            True
        )  # True if outside range (NA -> invalid)

        invalid_mask = (is_empty | len_invalid).fillna(
            True
        )  # empty OR bad length -> invalid

        # build message text
        if min_len == max_len:
            msg = f"Error at column [{col}] - value must be exactly {min_len} characters; \n"
        else:
            msg = f"Error at column [{col}] - value must be between {min_len} and {max_len} characters; \n"

        # 4) append error message for invalid rows
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + msg
        )

    return df


def _check_acct_holder_type(
    df: pd.DataFrame,
    col_acct_holder_type: dict,
) -> pd.DataFrame:
    # check if columns exists
    missing = [col not in df.columns for col in col_acct_holder_type]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in col_acct_holder_type:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(CONST.VALID_ACCT_HOLDER_TYPE)
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Invalid currency code. Must be ISO 4217 three-byte alpha from the standard list; \n"
        )

    return df

def _check_bool (
    df: pd.DataFrame,
    cols_bool: dict,
) -> pd.DataFrame:
        # check if columns exists
    missing = [col not in df.columns for col in cols_bool]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    for col in cols_bool:
        df[col] = df[col].str.upper()
        invalid_mask = ~(
            df[col]
            .astype("string")
            .str.strip()
            .str.upper()
            .isin(["TRUE", "FALSE"])
            .fillna(False)  # NaN -> False -> then ~ -> True (invalid)
        )

        # 2) append error message (safe for NaN / missing existing msg)
        df.loc[invalid_mask, CONST.COL_CHECK_ERROR] = (
            df.loc[invalid_mask, CONST.COL_CHECK_ERROR].astype("string").fillna("")
            + f"Error at column [{col}] - Invalid currency code. Must be ISO 4217 three-byte alpha from the standard list; \n"
        )

    return df


def validate_sheet_message_header(
    df,
) -> pd.DataFrame:

    if len(df) > 1:
        df.loc[CONST.COL_CHECK_ERROR] += " There should only be 1 line for this sheet"

    cols_blanks = [CONST.COL_WARNING, CONST.COL_CONTACT]
    cols_msgTypeIndic = [CONST.COL_MESSAGETYPEINDIC]
    cols_country = [CONST.COL_TRANSMITTINGCOUNTRY, CONST.COL_RECEIVINGCOUNTRY]
    cols_fixedvalue = [CONST.COL_MESSAGETYPE]
    cols_IN = [CONST.COL_SENDINGCOMPANYIN]
    cols_fixed_length = {CONST.COL_MESSAGEREFID: {"min": 10, "max": 10}}
    df = _check_org_IN(df, cols_IN)
    df = _check_country(df, cols_country)
    df = _check_fixed_value(df, cols_fixedvalue, "CRS")
    df = _check_blank(df, cols_blanks)
    df = _check_msgTypeIndic(df, cols_msgTypeIndic)
    df = _check_fixed_length(df, cols_fixed_length)

    return df


def validate_sheet_rpt_FI(
    df: pd.DataFrame,
) -> pd.DataFrame:

    if len(df) > 1:
        df.loc[CONST.COL_CHECK_ERROR] += "There should only be 1 line for this sheet"

    cols_doc_type_indic = [CONST.COL_DOCTYPEINDIC]
    cols_IN = [CONST.COL_IN]
    cols_country = [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE]

    cols_msgTypeIndic = [CONST.COL_MESSAGETYPEINDIC]
    cols_fixed_length = {
        CONST.COL_DOCREFID: {"min": 10, "max": 10},
        CONST.COL_NAME: {"min": 1, "max": 200},
        CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000},
        CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200},
    }

    df = _check_IN(df, cols_IN)
    df = _check_doc_type_indic(df, cols_doc_type_indic)
    df = _check_country(df, cols_country)
    df = _check_msgTypeIndic(df, cols_msgTypeIndic)
    df = _check_fixed_length(df, cols_fixed_length)


def validate_sheet_reportable_org_acc(
    df: pd.DataFrame,
) -> pd.DataFrame:

    if len(df) > 1:
        df.loc[CONST.COL_CHECK_ERROR] += "There should only be 1 line for this sheet"

    cols_doc_type_indic = [CONST.COL_DOCTYPEINDIC]
    cols_country = [CONST.COL_RESCOUNTRYCODE, CONST.COL_COUNTRYCODE]
    cols_currency_code = [
        CONST.COL_CURRCODE,
        CONST.COL_DIVIDENDS_PAYMENT_CURRCODE,
        CONST.COL_INTEREST_PAYMENT_CURRCODE,
        CONST.COL_GROSS_PROCEEDS_PAYMENT_CURRCODE,
        CONST.COL_OTHER_PAYMENT_CURRCODE,
    ]
    cols_IN = [CONST.COL_IN]
    cols_numeric = [
        CONST.COL_ACCOUNT_BALANCE,
        CONST.COL_DIVIDENDS_PAYMENT_AMOUNT,
        CONST.COL_INTEREST_PAYMENT_AMOUNT,
        CONST.COL_GROSS_PROCEEDS_PAYMENT_AMOUNT,
        CONST.COL_OTHER_PAYMENT_AMOUNT,
    ]
    cols_fixed_length = {
        CONST.COL_DOCREFID: {"min": 10, "max": 10},
        CONST.COL_NAME: {"min": 1, "max": 200},
        CONST.COL_IN: {"min": 8, "max": 200},
        CONST.COL_ADDRESSFREE: {"min": 1, "max": 4000},
        CONST.COL_ADDRESSFIX_STREET: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_BUILDINGID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_SUITEID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_FLOORID: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_DISTRICT_NAME: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_POB: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_POST_CODE: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_CITY: {"min": 0, "max": 200},
        CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY: {"min": 0, "max": 200},
    }
    cols_acct_holder_type = [CONST.COL_ACCTHOLDERTYPE]
    cols_bool = [CONST.COL_ACCOUNT_CLOSED]

    df = _check_IN(df, cols_IN)
    df = _check_numeric(df, cols_numeric)
    df = _check_currency_code(df, cols_currency_code)
    df = _check_doc_type_indic(df, cols_doc_type_indic)
    df = _check_country(df, cols_country)
    df = _check_fixed_length(df, cols_fixed_length)
    df = _check_acct_holder_type(df, cols_acct_holder_type)
    df = _check_bool(df, cols_bool)


def validate_sheet(
    dfs: str,
    outpath: str,
) -> bool:
    # check if sheet has all the requried sheets
    missing = [s for s in SHEETS_TO_READ if s not in dfs]
    if missing:
        raise KeyError(f"Missing required sheets: {missing}")

    dfs = [df.copy() for df in dfs]

    for df in dfs:
        df[CONST.COL_CHECK_REPORTABLE] = ""
        df[CONST.COL_CHECK_ERROR] = ""

    # For each sheet identify which col
    #  (1) required numeric check - 2d.p
    #  (2) requires country check - from enum list
    #  (3) Customer checks
    #       (i)     controlling person
    #       (ii)    doc spec numbers
    #       (iii)   Other companies formatting checks
    #
    # Output to an external excel adding 2 columns
    #   (i)     Reportable
    #   (ii)    Errors (if any)

    df_msg_header = validate_sheet_message_header(df[CONST.SHEET_MSG_HEADER])
    df_rpt_FI = validate_sheet_Reporting_FI(df[CONST.SHEET_RPT_FI])
