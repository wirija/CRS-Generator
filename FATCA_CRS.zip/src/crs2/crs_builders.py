from src.crs2.read_excel_const import CONST as CONST
from datetime import datetime, timezone
import pandas as pd
from xsdata.models.datatype import XmlDate, XmlDateTime
from typing import Iterable, Any
import secrets

from schema.crs2.crs2_schema import (
    CountryCodeType,
    AddressFixType,
    AddressType,
    OecddocTypeIndicEnumType,
    DocSpecType,
    CorrectableAccountReportType,
    FiaccountNumberType,
    MonAmntType,
    CurrCodeType,
    AccountHolderType,
    PersonPartyType,
    TinType,
    NamePersonType,
    PaymentType,
    CrsPaymentTypeEnumType,
    ControllingPersonType,
    CrsCtrlgPersonTypeEnumType,
    CrsAcctHolderTypeEnumType,
    OrganisationPartyType,
    OrganisationInType,
    NameOrganisationType,
)

# def _none_if_blank(v: str | None) -> str | None:
#     if v is None:
#         return None
#     v = str(v).strip()
#     return v if v else None


def _parse_xmldate(
    s: str | None,
) -> XmlDate:
    """
    Accepts common CRS-style inputs:
    - '2025-12-31'
    - '2025-01-01'
    - possibly '2025' (if your template uses year only; see note below)
    """
    s = s
    if not s:
        raise ValueError("ReportingPeriod is required")

    # If your Excel provides only 'YYYY', decide your convention:
    # CRS commonly uses the year-end date; adjust if needed.
    if len(s) == 4 and s.isdigit():
        s = f"{s}-12-31"

    return XmlDate.from_string(s)


def _parse_xmldatetime(
    s: str | None,
) -> XmlDateTime:
    s = s
    if not s:
        dt = datetime.now(timezone.utc).replace(microsecond=0, tzinfo=None)
        return XmlDateTime.from_datetime(dt)

    # Expecting ISO-like 'YYYY-MM-DDTHH:MM:SS' (or with timezone)
    return XmlDateTime.from_string(s)


def _all_none(
    x: Iterable[Any],
) -> bool:
    """Return True if every item in x is None (and x is non-empty)."""
    return all(v is None for v in x)


## ---------------------- Smalller builders functions ------------------------------
##  For reporting indv and co - they data requyirements is about the same
## ---------------------------------------------------------------------------------
def _build_person_party_type(
    row: dict,
) -> PersonPartyType:
    return PersonPartyType(
        res_country_code=[
            CountryCodeType(value=row.get(CONST.COL_RESCOUNTRYCODE) or "")
        ],
        tin=[TinType(value=row.get(CONST.COL_TIN) or "")],
        name=NamePersonType(
            first_name=NamePersonType.FirstName(
                value=(row.get(CONST.COL_FIRST_NAME) or "").strip()
            ),
            last_name=NamePersonType.LastName(
                value=(row.get(CONST.COL_LAST_NAME) or "").strip()
            ),
            middle_name=(
                [
                    NamePersonType.MiddleName(
                        value=(row.get(CONST.COL_MIDDLE_NAME) or "").strip()
                    )
                ]
                if (
                    row.get(CONST.COL_MIDDLE_NAME) is not None
                    and str(row.get(CONST.COL_MIDDLE_NAME)).strip() != ""
                )
                else []
            ),
        ),
        address=build_address(row),
    )


def _build_org_party_type(
    row: dict,
) -> OrganisationPartyType:
    res_country_code = row.get(CONST.COL_RESCOUNTRYCODE)
    in_value = row.get(CONST.COL_IN)
    in_issued_by = row.get(CONST.COL_IN_ISSUED_BY)
    name = row.get(CONST.COL_NAME)
    address = build_address(row)

    return OrganisationPartyType(
        res_country_code=[CountryCodeType(res_country_code)],
        in_value=[OrganisationInType(value=in_value, issued_by= CountryCodeType(in_issued_by))],
        name=[NameOrganisationType(value=name)],
        address=address,
    )


def _build_account_holder_type(
    row: dict,
    indv: bool = True,
) -> AccountHolderType:

    if indv:
        return AccountHolderType(individual=_build_person_party_type(row))

    else:
        return AccountHolderType(
            organisation=_build_org_party_type(row),
            acct_holder_type=CrsAcctHolderTypeEnumType(
                row.get(CONST.COL_ACCTHOLDERTYPE)
            ),
        )


def _build_payment(
    row: dict,
) -> list[PaymentType]:
    return [
        # -- Dividends
        PaymentType(
            type_value=CrsPaymentTypeEnumType("CRS501"),
            payment_amnt=MonAmntType(
                value=row.get(CONST.COL_DIVIDENDS_PAYMENT_AMOUNT),
                curr_code=row.get(CONST.COL_DIVIDENDS_PAYMENT_CURRCODE),
            ),
        ),
        # -- Interest
        PaymentType(
            type_value=CrsPaymentTypeEnumType("CRS502"),
            payment_amnt=MonAmntType(
                value=row.get(CONST.COL_INTEREST_PAYMENT_AMOUNT),
                curr_code=row.get(CONST.COL_INTEREST_PAYMENT_CURRCODE),
            ),
        ),
        # -- Gross Proceeds/Redemptions
        PaymentType(
            type_value=CrsPaymentTypeEnumType("CRS503"),
            payment_amnt=MonAmntType(
                value=row.get(CONST.COL_GROSS_PROCEEDS_PAYMENT_AMOUNT),
                curr_code=row.get(CONST.COL_GROSS_PROCEEDS_PAYMENT_CURRCODE),
            ),
        ),
        # -- Other - CRS
        PaymentType(
            type_value=CrsPaymentTypeEnumType("CRS504"),
            payment_amnt=MonAmntType(
                value=row.get(CONST.COL_OTHER_PAYMENT_AMOUNT),
                curr_code=row.get(CONST.COL_OTHER_PAYMENT_CURRCODE),
            ),
        ),
    ]


def _build_docSpec_account(
    row: dict,
    reporting_period: str,
    sending_company_in: str,
) -> DocSpecType:

    num = "".join(secrets.choice("0123456789") for _ in range(30))
    doc_ref_id = str(reporting_period)[:4] + str(sending_company_in.split(' ')[-1].ljust(10, "-")) + str(num)
    return DocSpecType(
        doc_type_indic=OecddocTypeIndicEnumType(row.get(CONST.COL_DOCTYPEINDIC)),
        doc_ref_id=doc_ref_id,
        corr_doc_ref_id=row.get(CONST.COL_CORRDOCREFID),
    )


def _build_account_balance(
    row: dict,
) -> MonAmntType:
    return MonAmntType(
        value=row.get(CONST.COL_ACCOUNT_BALANCE),
        curr_code=CurrCodeType(row.get(CONST.COL_CURRCODE)),
    )


def _build_fi_account_number_type(
    row: dict,
) -> FiaccountNumberType:
    return FiaccountNumberType(
        value=row.get(CONST.COL_ACCOUNTNUMBER),
        undocumented_account=(
            True if row.get(CONST.COL_ACCOUNT_UNDOCUMENTED) else False
        ),
        closed_account=True if row.get(CONST.COL_ACCOUNT_CLOSED) else False,
    )


def _build_controlling_persons(
    rows_controlling_person: list[dict],
) -> ControllingPersonType:
    return (
        [
            ControllingPersonType(
                individual=_build_person_party_type(row),
                ctrlg_person_type=CrsCtrlgPersonTypeEnumType(
                    row.get(CONST.COL_CTRLGPERSONTYPE)
                ),
            )
            for row in rows_controlling_person
        ]
        if not rows_controlling_person == None
        else []
    )


def build_address(
    row: dict,
    legal_address_type=None,
) -> AddressType:
    
    country_code = row.get(CONST.COL_COUNTRYCODE)

    address_free = row.get(CONST.COL_ADDRESSFREE)
    if not (row.get(CONST.COL_ADDRESSFIX_CITY)) == None:
        address_fix = AddressFixType(
            street=(row.get(CONST.COL_ADDRESSFIX_STREET)),
            building_identifier=(row.get(CONST.COL_ADDRESSFIX_BUILDINGID)),
            suite_identifier=(row.get(CONST.COL_ADDRESSFIX_SUITEID)),
            floor_identifier=(row.get(CONST.COL_ADDRESSFIX_FLOORID)),
            district_name=(row.get(CONST.COL_ADDRESSFIX_DISTRICT_NAME)),
            post_code=(row.get(CONST.COL_ADDRESSFIX_POST_CODE)),
            country_subentity=(row.get(CONST.COL_ADDRESSFIX_COUNTRY_SUBENTITY)),
            city=(row.get(CONST.COL_ADDRESSFIX_CITY)),
        )
    else:
        address_fix = None

    return AddressType(
        address_free=address_free,
        address_fix=address_fix,
        legal_address_type=legal_address_type,
        country_code=country_code,
    )


def build_doc_spec(
    row: dict,
    reporting_period,
    sending_company_in
) -> DocSpecType:
    
    if row.get(CONST.COL_DOCREFID) == None:
        num = "".join(secrets.choice("0123456789") for _ in range(30))
        doc_ref_id = str(reporting_period)[:4] + str(sending_company_in.split(' ')[-1].ljust(10, "-")) + str(num)
    else:
        doc_ref_id = row.get(CONST.COL_DOCREFID)

    return DocSpecType(
        doc_type_indic=OecddocTypeIndicEnumType((row.get(CONST.COL_DOCTYPEINDIC))),
        doc_ref_id=doc_ref_id,
        corr_doc_ref_id=(row.get(CONST.COL_CORRDOCREFID)),
        corr_message_ref_id=(row.get(CONST.COL_CORRMSGREFID)),
    )


def build_reportable_indiv(
    rows: list[dict],
    reporting_period: str,
    sending_company_in: str,
) -> list[CorrectableAccountReportType]:

    results = []
    for row in rows:

        account_number = _build_fi_account_number_type(row)
        account_balance = _build_account_balance(row)
        account_holder = _build_account_holder_type(
            row,
            indv=True,
        )
        payments = _build_payment(row)
        doc_spec = _build_docSpec_account(
            row=row,
            reporting_period=reporting_period,
            sending_company_in=sending_company_in,
        )

        results.append(
            CorrectableAccountReportType(
                doc_spec=doc_spec,
                account_number=account_number,
                account_balance=account_balance,
                account_holder=account_holder,
                payment=payments,
            )
        )

    return results


def build_reportable_org(
    rows: list[dict],
    rows_controlling_person: dict[str, list[dict[str, Any]]],
    reporting_period: str,
    sending_company_in: str,
) -> list[CorrectableAccountReportType]:
    results = []
    for row in rows:
        account_number = _build_fi_account_number_type(row)
        account_balance = _build_account_balance(row)
        account_holder = _build_account_holder_type(
            row,
            indv=False,
        )
        payments = _build_payment(row)
        doc_spec = _build_docSpec_account(
            row=row,
            reporting_period=reporting_period,
            sending_company_in=sending_company_in,
        )
        controlling_persons = _build_controlling_persons(
            rows_controlling_person.get(row.get(CONST.COL_ACCOUNTNUMBER))
        )
        results.append(
            CorrectableAccountReportType(
                doc_spec=doc_spec,
                account_number=account_number,
                account_balance=account_balance,
                account_holder=account_holder,
                payment=payments,
                controlling_person=controlling_persons,
            )
        )

    return results
