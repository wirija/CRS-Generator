from __future__ import annotations

from pathlib import Path

import pandas as pd

from src.fatca.excel_validator.validation_config import SHEET_RULES
from src.fatca.excel_validator.validation_rules import (
    check_allowed_values,
    check_birthdates,
    check_blank,
    check_fixed_length,
    check_fixed_value,
    check_name,
    check_numeric_2dp,
    check_GIIN,
    check_TIN,
    check_GIIN_TIN,
    check_single_row,
    warning_TIN_wo_city,
)
from src.fatca.read_excel import SHEETS_TO_READ
from src.fatca.read_excel_const import CONST


def apply_rule(df: pd.DataFrame, rule: dict) -> pd.DataFrame:
    """Dispatch one configured rule to the appropriate validation function."""
    rule_type = rule["type"]  # Read the configured rule name once

    if rule_type == "single_row":
        return check_single_row(df)  # Validate that only one row exists

    if rule_type == "format_GIIN":
        return check_GIIN(
            df,
            cols_in=rule["cols"],
        )

    if rule_type == "format_TIN":
        return check_TIN(
            df,
            cols_in=rule["cols"],
        )

    if rule_type == "format_GIIN_TIN":
        return check_GIIN_TIN(
            df,
            cols_in=rule["cols"],
        )

    if rule_type == "blank":
        return check_blank(
            df,
            cols_blank=rule["cols"],
        )

    if rule_type == "fixed_value":
        return check_fixed_value(
            df,
            cols_fixed_value=rule["cols"],
            value=rule["value"],
        )

    if rule_type == "numeric_2dp":
        return check_numeric_2dp(
            df,
            cols_numeric=rule["cols"],
            allow_blank=rule.get("allow_blank", False),
        )

    if rule_type == "fixed_length":
        return check_fixed_length(
            df,
            col_lengths=rule["col_lengths"],
        )

    if rule_type == "allowed_values":
        return check_allowed_values(
            df,
            cols=rule["cols"],
            valid_values=rule["valid_values"],
            message_template=rule["message"],
            upper=rule.get("upper", True),
            allow_blank=rule.get("allow_blank", False),
        )

    if rule_type == "check_names":
        return check_name(
            df,
            cols_names=rule["cols"],
        )

    if rule_type == "check_birthdates":
        return check_birthdates(
            df,
            cols_birthdates=rule["cols"],
        )
    
    if rule_type == 'warning_missing_TIN_city':
        return warning_TIN_wo_city(
            df,
            cols_TIN_city=rule["cols"]
        )

    raise ValueError(
        f"Unsupported rule type: {rule_type}"
    )  # Force explicit handling of every rule type
