from schema.fatca.fatca_schema import (
    CountryCodeType,
    CurrCodeType,
    FatcaAcctHolderTypeEnumType,
    FatcaDocTypeIndicEnumType,
)


class CONST:
    SHEET_MSG_HEADER = "Message Header"
    SHEET_REPORTING_FI = "Reporting FI"
    SHEET_SPONSOR = 'Sponsor'
    SHEET_REPORTABLE_INDIV_ACC = "Reportable Individual Account"
    SHEET_REPORTABLE_ORG_ACC = "Reportable Organisation Account"
    SHEET_SUBSTANTIAL_OWNER_INDIV = "Substantial Owner (Individual)"
    SHEET_SUBSTANTIAL_OWNER_ORG = "Substantial Owner (Organisatio)"
    SHEET_REPORTABLE_JURISDICTION = "Reportable Jurisdictions"

    # -- Message -- #
    COL_REPORTABLE_JURISDICTION = "ResCountryCode /\nTINissuedBy"

    # -- Message Header -- #
    COL_SENDINGCOMPANYIN = "SendingCompanyIN"
    COL_TRANSMITTINGCOUNTRY = "TransmittingCountry"
    COL_RECEIVINGCOUNTRY = "ReceivingCountry"
    COL_WARNING = "Warning"
    COL_CONTACT = "Contact"
    COL_MESSAGEREFID = "MessageRefID"
    COL_REPORTINGPERIOD = "ReportingPeriod"
    COL_MESSAGETYPE = 'MessageType'

    # -- Reporting FI -- #
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_TIN = "TIN"
    COL_NAME = "Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_CORRMSGREFID = "CorrMessageRefID"
    COL_TIN_ISSUED_BY = "TIN_Issued_By"
    COL_FILER_CATEGORY = "FilerCategory"
    COL_NIL_ACCOUNT = "Nil Accounts?"

    # -- Reportable Individual Account -- #
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_TIN = "TIN"
    COL_TIN_ISSUED_BY = "TIN_Issued_By"
    COL_FIRST_NAME = "First_Name"
    COL_MIDDLE_NAME = "Middle_Name"
    COL_LAST_NAME = "Last_Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"  ## Need to update to address Fix
    COL_ADDRESSFREE = "AddressFree"
    COL_BIRTHDATE = "BirthDate"
    COL_ACCOUNT_BALANCE = "Account_Balance"
    COL_CURRCODE = "currCode"
    COL_DIVIDENDS_PAYMENT_AMOUNT = "Dividends_Payment_Amount"
    COL_DIVIDENDS_PAYMENT_CURRCODE = "Dividends_Payment_CurrCode"
    COL_INTEREST_PAYMENT_AMOUNT = "Interest_Payment_Amount"
    COL_INTEREST_PAYMENT_CURRCODE = "Interest_Payment_CurrCode"
    COL_GROSS_PROCEEDS_PAYMENT_AMOUNT = "Gross_Proceeds_Payment_Amount"
    COL_GROSS_PROCEEDS_PAYMENT_CURRCODE = "Gross_Proceeds_Payment_CurrCode"
    COL_OTHER_PAYMENT_AMOUNT = "Other_Payment_Amount"
    COL_OTHER_PAYMENT_CURRCODE = "Other_Payment_CurrCode"
    COL_ACCOUNT_CLOSED = "Account_Closed?"
    COL_ACCOUNT_UNDOCUMENTED = "Account_Undocumented?"
    COL_NATIONALITY = "Nationality"
    COL_BIRTHDATE = "BirthDate"

    # -- Reportable Organisation Account -- #
    COL_DOCTYPEINDIC = "DocTypeIndic"
    COL_DOCREFID = "DocRefID"
    COL_CORRDOCREFID = "CorrDocRefID"
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_IN = "IN"
    COL_IN_ISSUED_BY = "IN_issued_by"
    COL_NAME = "Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ACCTHOLDERTYPE = "AcctHolderType"
    COL_ACCOUNT_BALANCE = "Account_Balance"
    COL_CURRCODE = "currCode"
    COL_DIVIDENDS_PAYMENT_AMOUNT = "Dividends_Payment_Amount"
    COL_DIVIDENDS_PAYMENT_CURRCODE = "Dividends_Payment_CurrCode"
    COL_INTEREST_PAYMENT_AMOUNT = "Interest_Payment_Amount"
    COL_INTEREST_PAYMENT_CURRCODE = "Interest_Payment_CurrCode"
    COL_GROSS_PROCEEDS_PAYMENT_AMOUNT = "Gross_Proceeds_Payment_Amount"
    COL_GROSS_PROCEEDS_PAYMENT_CURRCODE = "Gross_Proceeds_Payment_CurrCode"
    COL_OTHER_PAYMENT_AMOUNT = "Other_Payment_Amount"
    COL_OTHER_PAYMENT_CURRCODE = "Other_Payment_CurrCode"

    # -- Controlling Person (Individual) -- #
    COL_ACCOUNTNUMBER = "AccountNumber"
    COL_RESCOUNTRYCODE = "ResCountryCode"
    COL_TIN = "TIN"
    COL_TIN_ISSUED_BY = "TIN_Issued_By"
    COL_FIRST_NAME = "First_Name"
    COL_MIDDLE_NAME = "Middle_Name"
    COL_LAST_NAME = "Last_Name"
    COL_COUNTRYCODE = "CountryCode"
    COL_ADDRESSFREE = "AddressFree"
    COL_BIRTHDATE = "BirthDate"
    COL_CTRLGPERSONTYPE = "CtrlgPersonType"

    # -- Address fix / Free -- #
    COL_ADDRESSFREE = "AddressFree"
    COL_ADDRESSFIX_STREET = "Street"
    COL_ADDRESSFIX_BUILDINGID = "Building Identifier"
    COL_ADDRESSFIX_SUITEID = "Suite Identifier"
    COL_ADDRESSFIX_FLOORID = "Floor Identifier"
    COL_ADDRESSFIX_DISTRICT_NAME = "District Name"
    COL_ADDRESSFIX_POB = "POB"
    COL_ADDRESSFIX_POST_CODE = "Post Code"
    COL_ADDRESSFIX_CITY = "City"
    COL_ADDRESSFIX_COUNTRY_SUBENTITY = "Country Subentity"

    # -- Validation checks
    COL_CHECK_REPORTABLE = "Reportable?"
    COL_CHECK_ERROR = "Error"
    COL_CHECK_WARNING = "Warning"


    # -- Other Constants list
    VALID_DOC_TYPE_INDIC = {e.value for e in FatcaDocTypeIndicEnumType}
    VALID_COUNTRY_CODES = {e.value for e in CountryCodeType}
    VALID_CURRENCY_CODES = {e.value for e in CurrCodeType}
    VALID_ACCT_HOLDER_TYPE = {e.value for e in FatcaAcctHolderTypeEnumType}

    # -- Cols for checks
    VALIDATE_MSG_HEADER_COUNTRIES = [
        COL_TRANSMITTINGCOUNTRY,
        COL_RECEIVINGCOUNTRY,
    ]
