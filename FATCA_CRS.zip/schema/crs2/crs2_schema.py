from __future__ import annotations

from dataclasses import dataclass, field
from decimal import Decimal
from enum import Enum

from xsdata.models.datatype import XmlDate, XmlDateTime


class AcctNumberTypeEnumType(Enum):
    """
    Account Number Type.

    :cvar OECD601: IBAN
    :cvar OECD602: OBAN
    :cvar OECD603: ISIN
    :cvar OECD604: OSIN
    :cvar OECD605: Other
    """

    OECD601 = "OECD601"
    OECD602 = "OECD602"
    OECD603 = "OECD603"
    OECD604 = "OECD604"
    OECD605 = "OECD605"


@dataclass(kw_only=True)
class AddressFixType:
    """
    Structure of the address for a party broken down into its logical
    parts, recommended for easy matching.

    The 'City' element is the only required subelement. All of the
    subelements are simple text - data type 'string'.
    """

    class Meta:
        name = "AddressFix_Type"
        target_namespace = "urn:oecd:ties:commontypesfatcacrs:v2"

    street: None | str = field(
        default=None,
        metadata={
            "name": "Street",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    building_identifier: None | str = field(
        default=None,
        metadata={
            "name": "BuildingIdentifier",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    suite_identifier: None | str = field(
        default=None,
        metadata={
            "name": "SuiteIdentifier",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    floor_identifier: None | str = field(
        default=None,
        metadata={
            "name": "FloorIdentifier",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    district_name: None | str = field(
        default=None,
        metadata={
            "name": "DistrictName",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    pob: None | str = field(
        default=None,
        metadata={
            "name": "POB",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    post_code: None | str = field(
        default=None,
        metadata={
            "name": "PostCode",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    city: str = field(
        metadata={
            "name": "City",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        }
    )
    country_subentity: None | str = field(
        default=None,
        metadata={
            "name": "CountrySubentity",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )


class CrsAcctHolderTypeEnumType(Enum):
    """
    Account Holder Type.

    :cvar CRS101: Passive Non-Financial Entity with one or more
        controlling person that is a Reportable Person
    :cvar CRS102: CRS Reportable Person
    :cvar CRS103: Passive NFE that is a CRS Reportable Person
    """

    CRS101 = "CRS101"
    CRS102 = "CRS102"
    CRS103 = "CRS103"


class CrsCtrlgPersonTypeEnumType(Enum):
    """
    Controlling Person Type.

    :cvar CRS801: CP of legal person - ownership
    :cvar CRS802: CP of legal person - other means
    :cvar CRS803: CP of legal person - senior managing official
    :cvar CRS804: CP of legal arrangement - trust - settlor
    :cvar CRS805: CP of legal arrangement - trust - trustee
    :cvar CRS806: CP of legal arrangement - trust - protector
    :cvar CRS807: CP of legal arrangement - trust - beneficiary
    :cvar CRS808: CP of legal arrangement - trust - other
    :cvar CRS809: CP of legal arrangement - other - settlor-equivalent
    :cvar CRS810: CP of legal arrangement - other - trustee-equivalent
    :cvar CRS811: CP of legal arrangement - other - protector-equivalent
    :cvar CRS812: CP of legal arrangement - other - beneficiary-
        equivalent
    :cvar CRS813: CP of legal arrangement - other - other-equivalent
    """

    CRS801 = "CRS801"
    CRS802 = "CRS802"
    CRS803 = "CRS803"
    CRS804 = "CRS804"
    CRS805 = "CRS805"
    CRS806 = "CRS806"
    CRS807 = "CRS807"
    CRS808 = "CRS808"
    CRS809 = "CRS809"
    CRS810 = "CRS810"
    CRS811 = "CRS811"
    CRS812 = "CRS812"
    CRS813 = "CRS813"


class CrsMessageTypeIndicEnumType(Enum):
    """
    The MessageTypeIndic defines the type of message sent.

    :cvar CRS701: The message contains new information
    :cvar CRS702: The message contains corrections for previously sent
        information
    :cvar CRS703: The message advises there is no data to report
    """

    CRS701 = "CRS701"
    CRS702 = "CRS702"
    CRS703 = "CRS703"


class CrsPaymentTypeEnumType(Enum):
    """
    The code describing the nature of the payments used in CRS.

    :cvar CRS501: Dividends
    :cvar CRS502: Interest
    :cvar CRS503: Gross Proceeds/Redemptions
    :cvar CRS504: Other - CRS
    """

    CRS501 = "CRS501"
    CRS502 = "CRS502"
    CRS503 = "CRS503"
    CRS504 = "CRS504"


class MessageTypeEnumType(Enum):
    """
    Message type defines the type of reporting.
    """

    CRS = "CRS"


class OecddocTypeIndicEnumType(Enum):
    """
    This element specifies the type of data being submitted.

    :cvar OECD0: Resend Data
    :cvar OECD1: New Data
    :cvar OECD2: Corrected Data
    :cvar OECD3: Deletion of Data
    :cvar OECD10: Resend Test Data
    :cvar OECD11: New Test Data
    :cvar OECD12: Corrected Test Data
    :cvar OECD13: Deletion of Test Data
    """

    OECD0 = "OECD0"
    OECD1 = "OECD1"
    OECD2 = "OECD2"
    OECD3 = "OECD3"
    OECD10 = "OECD10"
    OECD11 = "OECD11"
    OECD12 = "OECD12"
    OECD13 = "OECD13"


class OecdlegalAddressTypeEnumType(Enum):
    """
    This is a datatype for an attribute to an address.

    It serves to indicate the legal character of that address (residential,
    business etc.).

    :cvar OECD301: residentialOrBusiness
    :cvar OECD302: residential
    :cvar OECD303: business
    :cvar OECD304: registeredOffice
    :cvar OECD305: unspecified
    """

    OECD301 = "OECD301"
    OECD302 = "OECD302"
    OECD303 = "OECD303"
    OECD304 = "OECD304"
    OECD305 = "OECD305"


class OecdnameTypeEnumType(Enum):
    """
    It is possible for stf documents to contain several names for the same
    party.

    This is a qualifier to indicate the type of a particular name. Such
    types include nicknames ('nick'), names under which a party does
    business ('dba' a short name for the entity, or a name that is used for
    public acquaintance instead of the official business name) etc.

    :cvar OECD201: SMFAliasOrOther
    :cvar OECD202: indiv (individual)
    :cvar OECD203: alias (alias)
    :cvar OECD204: nick (nickname)
    :cvar OECD205: aka (also known as)
    :cvar OECD206: dba (doing business as)
    :cvar OECD207: legal (legal name)
    :cvar OECD208: atbirth (name at birth)
    """

    OECD201 = "OECD201"
    OECD202 = "OECD202"
    OECD203 = "OECD203"
    OECD204 = "OECD204"
    OECD205 = "OECD205"
    OECD206 = "OECD206"
    OECD207 = "OECD207"
    OECD208 = "OECD208"


class FatcaAcctPoolReportTypeEnumType(Enum):
    """
    Account Pool Reporting Type.

    :cvar FATCA201: Recalcitrant account holders with US Indicia
    :cvar FATCA202: Recalcitrant account holders without US Indicia
    :cvar FATCA203: Dormant accounts
    :cvar FATCA204: Non-participating foreign financial institutions
    :cvar FATCA205: Recalcitrant account holders that are US persons
    :cvar FATCA206: Recalcitrant account holders that are passive NFFEs
    """

    FATCA201 = "FATCA201"
    FATCA202 = "FATCA202"
    FATCA203 = "FATCA203"
    FATCA204 = "FATCA204"
    FATCA205 = "FATCA205"
    FATCA206 = "FATCA206"


class CountryCodeType(Enum):
    """
    ISO-3166 Alpha 2 country codes.

    :cvar AF: AFGHANISTAN
    :cvar AX: ALAND ISLANDS
    :cvar AL: ALBANIA
    :cvar DZ: ALGERIA
    :cvar AS: AMERICAN SAMOA
    :cvar AD: ANDORRA
    :cvar AO: ANGOLA
    :cvar AI: ANGUILLA
    :cvar AQ: ANTARCTICA
    :cvar AG: ANTIGUA AND BARBUDA
    :cvar AR: ARGENTINA
    :cvar AM: ARMENIA
    :cvar AW: ARUBA
    :cvar AU: AUSTRALIA
    :cvar AT: AUSTRIA
    :cvar AZ: AZERBAIJAN
    :cvar BS: BAHAMAS
    :cvar BH: BAHRAIN
    :cvar BD: BANGLADESH
    :cvar BB: BARBADOS
    :cvar BY: BELARUS
    :cvar BE: BELGIUM
    :cvar BZ: BELIZE
    :cvar BJ: BENIN
    :cvar BM: BERMUDA
    :cvar BT: BHUTAN
    :cvar BO: BOLIVIA, PLURINATIONAL STATE OF
    :cvar BQ: BONAIRE, SINT EUSTATIUS AND SABA
    :cvar BA: BOSNIA AND HERZEGOVINA
    :cvar BW: BOTSWANA
    :cvar BV: BOUVET ISLAND
    :cvar BR: BRAZIL
    :cvar IO: BRITISH INDIAN OCEAN TERRITORY
    :cvar BN: BRUNEI DARUSSALAM
    :cvar BG: BULGARIA
    :cvar BF: BURKINA FASO
    :cvar BI: BURUNDI
    :cvar KH: CAMBODIA
    :cvar CM: CAMEROON
    :cvar CA: CANADA
    :cvar CV: CABO VERDE
    :cvar KY: CAYMAN ISLANDS
    :cvar CF: CENTRAL AFRICAN REPUBLIC
    :cvar TD: CHAD
    :cvar CL: CHILE
    :cvar CN: CHINA
    :cvar CX: CHRISTMAS ISLAND
    :cvar CC: COCOS (KEELING) ISLANDS
    :cvar CO: COLOMBIA
    :cvar KM: COMOROS
    :cvar CG: CONGO
    :cvar CD: CONGO, THE DEMOCRATIC REPUBLIC OF THE
    :cvar CK: COOK ISLANDS
    :cvar CR: COSTA RICA
    :cvar CI: COTE D'IVOIRE
    :cvar HR: CROATIA
    :cvar CU: CUBA
    :cvar CW: CURACAO
    :cvar CY: CYPRUS
    :cvar CZ: CZECHIA
    :cvar DK: DENMARK
    :cvar DJ: DJIBOUTI
    :cvar DM: DOMINICA
    :cvar DO: DOMINICAN REPUBLIC
    :cvar EC: ECUADOR
    :cvar EG: EGYPT
    :cvar SV: EL SALVADOR
    :cvar GQ: EQUATORIAL GUINEA
    :cvar ER: ERITREA
    :cvar EE: ESTONIA
    :cvar ET: ETHIOPIA
    :cvar FK: FALKLAND ISLANDS (MALVINAS)
    :cvar FO: FAROE ISLANDS
    :cvar FJ: FIJI
    :cvar FI: FINLAND
    :cvar FR: FRANCE
    :cvar GF: FRENCH GUIANA
    :cvar PF: FRENCH POLYNESIA
    :cvar TF: FRENCH SOUTHERN TERRITORIES
    :cvar GA: GABON
    :cvar GM: GAMBIA
    :cvar GE: GEORGIA
    :cvar DE: GERMANY
    :cvar GH: GHANA
    :cvar GI: GIBRALTAR
    :cvar GR: GREECE
    :cvar GL: GREENLAND
    :cvar GD: GRENADA
    :cvar GP: GUADELOUPE
    :cvar GU: GUAM
    :cvar GT: GUATEMALA
    :cvar GG: GUERNSEY
    :cvar GN: GUINEA
    :cvar GW: GUINEA-BISSAU
    :cvar GY: GUYANA
    :cvar HT: HAITI
    :cvar HM: HEARD ISLAND AND MCDONALD ISLANDS
    :cvar VA: HOLY SEE (VATICAN CITY STATE)
    :cvar HN: HONDURAS
    :cvar HK: HONG KONG
    :cvar HU: HUNGARY
    :cvar IS: ICELAND
    :cvar IN: INDIA
    :cvar ID: INDONESIA
    :cvar IR: IRAN, ISLAMIC REPUBLIC OF
    :cvar IQ: IRAQ
    :cvar IE: IRELAND
    :cvar IM: ISLE OF MAN
    :cvar IL: ISRAEL
    :cvar IT: ITALY
    :cvar JM: JAMAICA
    :cvar JP: JAPAN
    :cvar JE: JERSEY
    :cvar JO: JORDAN
    :cvar KZ: KAZAKHSTAN
    :cvar KE: KENYA
    :cvar KI: KIRIBATI
    :cvar KP: KOREA, DEMOCRATIC PEOPLE'S REPUBLIC OF
    :cvar KR: KOREA, REPUBLIC OF
    :cvar KW: KUWAIT
    :cvar KG: KYRGYZSTAN
    :cvar LA: LAO PEOPLE'S DEMOCRATIC REPUBLIC
    :cvar LV: LATVIA
    :cvar LB: LEBANON
    :cvar LS: LESOTHO
    :cvar LR: LIBERIA
    :cvar LY: LIBYA
    :cvar LI: LIECHTENSTEIN
    :cvar LT: LITHUANIA
    :cvar LU: LUXEMBOURG
    :cvar MO: MACAO
    :cvar MK: NORTH MACEDONIA
    :cvar MG: MADAGASCAR
    :cvar MW: MALAWI
    :cvar MY: MALAYSIA
    :cvar MV: MALDIVES
    :cvar ML: MALI
    :cvar MT: MALTA
    :cvar MH: MARSHALL ISLANDS
    :cvar MQ: MARTINIQUE
    :cvar MR: MAURITANIA
    :cvar MU: MAURITIUS
    :cvar YT: MAYOTTE
    :cvar MX: MEXICO
    :cvar FM: MICRONESIA, FEDERATED STATES OF
    :cvar MD: MOLDOVA, REPUBLIC OF
    :cvar MC: MONACO
    :cvar MN: MONGOLIA
    :cvar ME: MONTENEGRO
    :cvar MS: MONTSERRAT
    :cvar MA: MOROCCO
    :cvar MZ: MOZAMBIQUE
    :cvar MM: MYANMAR
    :cvar NA: NAMIBIA
    :cvar NR: NAURU
    :cvar NP: NEPAL
    :cvar NL: NETHERLANDS
    :cvar NC: NEW CALEDONIA
    :cvar NZ: NEW ZEALAND
    :cvar NI: NICARAGUA
    :cvar NE: NIGER
    :cvar NG: NIGERIA
    :cvar NU: NIUE
    :cvar NF: NORFOLK ISLAND
    :cvar MP: NORTHERN MARIANA ISLANDS
    :cvar NO: NORWAY
    :cvar OM: OMAN
    :cvar PK: PAKISTAN
    :cvar PW: PALAU
    :cvar PS: PALESTINE, STATE OF
    :cvar PA: PANAMA
    :cvar PG: PAPUA NEW GUINEA
    :cvar PY: PARAGUAY
    :cvar PE: PERU
    :cvar PH: PHILIPPINES
    :cvar PN: PITCAIRN
    :cvar PL: POLAND
    :cvar PT: PORTUGAL
    :cvar PR: PUERTO RICO
    :cvar QA: QATAR
    :cvar RE: REUNION
    :cvar RO: ROMANIA
    :cvar RU: RUSSIAN FEDERATION
    :cvar RW: RWANDA
    :cvar BL: SAINT BARTHELEMY
    :cvar SH: SAINT HELENA, ASCENSION AND TRISTAN DA CUNHA
    :cvar KN: SAINT KITTS AND NEVIS
    :cvar LC: SAINT LUCIA
    :cvar MF: SAINT MARTIN (FRENCH PART)
    :cvar PM: SAINT PIERRE AND MIQUELON
    :cvar VC: SAINT VINCENT AND THE GRENADINES
    :cvar WS: SAMOA
    :cvar SM: SAN MARINO
    :cvar ST: SAO TOME AND PRINCIPE
    :cvar SA: SAUDI ARABIA
    :cvar SN: SENEGAL
    :cvar RS: SERBIA
    :cvar SC: SEYCHELLES
    :cvar SL: SIERRA LEONE
    :cvar SG: SINGAPORE
    :cvar SX: SINT MAARTEN (DUTCH PART)
    :cvar SK: SLOVAKIA
    :cvar SI: SLOVENIA
    :cvar SB: SOLOMON ISLANDS
    :cvar SO: SOMALIA
    :cvar ZA: SOUTH AFRICA
    :cvar GS: SOUTH GEORGIA AND THE SOUTH SANDWICH ISLANDS
    :cvar SS: SOUTH SUDAN
    :cvar ES: SPAIN
    :cvar LK: SRI LANKA
    :cvar SD: SUDAN
    :cvar SR: SURINAME
    :cvar SJ: SVALBARD AND JAN MAYEN
    :cvar SZ: ESWATINI
    :cvar SE: SWEDEN
    :cvar CH: SWITZERLAND
    :cvar SY: SYRIAN ARAB REPUBLIC
    :cvar TW: TAIWAN, PROVINCE OF CHINA
    :cvar TJ: TAJIKISTAN
    :cvar TZ: TANZANIA, UNITED REPUBLIC OF
    :cvar TH: THAILAND
    :cvar TL: TIMOR-LESTE
    :cvar TG: TOGO
    :cvar TK: TOKELAU
    :cvar TO: TONGA
    :cvar TT: TRINIDAD AND TOBAGO
    :cvar TN: TUNISIA
    :cvar TR: TURKEY
    :cvar TM: TURKMENISTAN
    :cvar TC: TURKS AND CAICOS ISLANDS
    :cvar TV: TUVALU
    :cvar UG: UGANDA
    :cvar UA: UKRAINE
    :cvar AE: UNITED ARAB EMIRATES
    :cvar GB: UNITED KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND
    :cvar US: UNITED STATES
    :cvar UM: UNITED STATES MINOR OUTLYING ISLANDS
    :cvar UY: URUGUAY
    :cvar UZ: UZBEKISTAN
    :cvar VU: VANUATU
    :cvar VE: VENEZUELA, BOLIVARIAN REPUBLIC OF
    :cvar VN: VIET NAM
    :cvar VG: VIRGIN ISLANDS, BRITISH
    :cvar VI: VIRGIN ISLANDS, U.S.
    :cvar WF: WALLIS AND FUTUNA
    :cvar EH: WESTERN SAHARA
    :cvar YE: YEMEN
    :cvar ZM: ZAMBIA
    :cvar ZW: ZIMBABWE
    :cvar XK: KOSOVO
    """

    AF = "AF"
    AX = "AX"
    AL = "AL"
    DZ = "DZ"
    AS = "AS"
    AD = "AD"
    AO = "AO"
    AI = "AI"
    AQ = "AQ"
    AG = "AG"
    AR = "AR"
    AM = "AM"
    AW = "AW"
    AU = "AU"
    AT = "AT"
    AZ = "AZ"
    BS = "BS"
    BH = "BH"
    BD = "BD"
    BB = "BB"
    BY = "BY"
    BE = "BE"
    BZ = "BZ"
    BJ = "BJ"
    BM = "BM"
    BT = "BT"
    BO = "BO"
    BQ = "BQ"
    BA = "BA"
    BW = "BW"
    BV = "BV"
    BR = "BR"
    IO = "IO"
    BN = "BN"
    BG = "BG"
    BF = "BF"
    BI = "BI"
    KH = "KH"
    CM = "CM"
    CA = "CA"
    CV = "CV"
    KY = "KY"
    CF = "CF"
    TD = "TD"
    CL = "CL"
    CN = "CN"
    CX = "CX"
    CC = "CC"
    CO = "CO"
    KM = "KM"
    CG = "CG"
    CD = "CD"
    CK = "CK"
    CR = "CR"
    CI = "CI"
    HR = "HR"
    CU = "CU"
    CW = "CW"
    CY = "CY"
    CZ = "CZ"
    DK = "DK"
    DJ = "DJ"
    DM = "DM"
    DO = "DO"
    EC = "EC"
    EG = "EG"
    SV = "SV"
    GQ = "GQ"
    ER = "ER"
    EE = "EE"
    ET = "ET"
    FK = "FK"
    FO = "FO"
    FJ = "FJ"
    FI = "FI"
    FR = "FR"
    GF = "GF"
    PF = "PF"
    TF = "TF"
    GA = "GA"
    GM = "GM"
    GE = "GE"
    DE = "DE"
    GH = "GH"
    GI = "GI"
    GR = "GR"
    GL = "GL"
    GD = "GD"
    GP = "GP"
    GU = "GU"
    GT = "GT"
    GG = "GG"
    GN = "GN"
    GW = "GW"
    GY = "GY"
    HT = "HT"
    HM = "HM"
    VA = "VA"
    HN = "HN"
    HK = "HK"
    HU = "HU"
    IS = "IS"
    IN = "IN"
    ID = "ID"
    IR = "IR"
    IQ = "IQ"
    IE = "IE"
    IM = "IM"
    IL = "IL"
    IT = "IT"
    JM = "JM"
    JP = "JP"
    JE = "JE"
    JO = "JO"
    KZ = "KZ"
    KE = "KE"
    KI = "KI"
    KP = "KP"
    KR = "KR"
    KW = "KW"
    KG = "KG"
    LA = "LA"
    LV = "LV"
    LB = "LB"
    LS = "LS"
    LR = "LR"
    LY = "LY"
    LI = "LI"
    LT = "LT"
    LU = "LU"
    MO = "MO"
    MK = "MK"
    MG = "MG"
    MW = "MW"
    MY = "MY"
    MV = "MV"
    ML = "ML"
    MT = "MT"
    MH = "MH"
    MQ = "MQ"
    MR = "MR"
    MU = "MU"
    YT = "YT"
    MX = "MX"
    FM = "FM"
    MD = "MD"
    MC = "MC"
    MN = "MN"
    ME = "ME"
    MS = "MS"
    MA = "MA"
    MZ = "MZ"
    MM = "MM"
    NA = "NA"
    NR = "NR"
    NP = "NP"
    NL = "NL"
    NC = "NC"
    NZ = "NZ"
    NI = "NI"
    NE = "NE"
    NG = "NG"
    NU = "NU"
    NF = "NF"
    MP = "MP"
    NO = "NO"
    OM = "OM"
    PK = "PK"
    PW = "PW"
    PS = "PS"
    PA = "PA"
    PG = "PG"
    PY = "PY"
    PE = "PE"
    PH = "PH"
    PN = "PN"
    PL = "PL"
    PT = "PT"
    PR = "PR"
    QA = "QA"
    RE = "RE"
    RO = "RO"
    RU = "RU"
    RW = "RW"
    BL = "BL"
    SH = "SH"
    KN = "KN"
    LC = "LC"
    MF = "MF"
    PM = "PM"
    VC = "VC"
    WS = "WS"
    SM = "SM"
    ST = "ST"
    SA = "SA"
    SN = "SN"
    RS = "RS"
    SC = "SC"
    SL = "SL"
    SG = "SG"
    SX = "SX"
    SK = "SK"
    SI = "SI"
    SB = "SB"
    SO = "SO"
    ZA = "ZA"
    GS = "GS"
    SS = "SS"
    ES = "ES"
    LK = "LK"
    SD = "SD"
    SR = "SR"
    SJ = "SJ"
    SZ = "SZ"
    SE = "SE"
    CH = "CH"
    SY = "SY"
    TW = "TW"
    TJ = "TJ"
    TZ = "TZ"
    TH = "TH"
    TL = "TL"
    TG = "TG"
    TK = "TK"
    TO = "TO"
    TT = "TT"
    TN = "TN"
    TR = "TR"
    TM = "TM"
    TC = "TC"
    TV = "TV"
    UG = "UG"
    UA = "UA"
    AE = "AE"
    GB = "GB"
    US = "US"
    UM = "UM"
    UY = "UY"
    UZ = "UZ"
    VU = "VU"
    VE = "VE"
    VN = "VN"
    VG = "VG"
    VI = "VI"
    WF = "WF"
    EH = "EH"
    YE = "YE"
    ZM = "ZM"
    ZW = "ZW"
    XK = "XK"


class CurrCodeType(Enum):
    """
    The appropriate currency code from the ISO 4217 three-byte alpha
    version for the currency in which a monetary amount is expressed.

    :cvar AED: UAE Dirham: UNITED ARAB EMIRATES
    :cvar AFN: Afghani: AFGHANISTAN
    :cvar ALL: Lek: ALBANIA
    :cvar AMD: Armenian Dram: ARMENIA
    :cvar ANG: Netherlands Antillean Guilder: CURACAO; SINT MAARTEN
        (DUTCH PART)
    :cvar AOA: Kwanza: ANGOLA
    :cvar ARS: Argentine Peso: ARGENTINA
    :cvar AUD: Australian Dollar: AUSTRALIA; CHRISTMAS ISLAND; COCOS
        (KEELING) ISLANDS; HEARD ISLAND AND McDONALD ISLANDS; KIRIBATI;
        NAURU; NORFOLK ISLAND; TUVALU
    :cvar AWG: Aruban Florin: ARUBA
    :cvar AZN: Azerbaijan Manat: AZERBAIJAN
    :cvar BAM: Convertible Mark: BOSNIA AND HERZEGOVINA
    :cvar BBD: Barbados Dollar: BARBADOS
    :cvar BDT: Taka: BANGLADESH
    :cvar BGN: Bulgarian Lev: BULGARIA
    :cvar BHD: Bahraini Dinar: BAHRAIN
    :cvar BIF: Burundi Franc: BURUNDI
    :cvar BMD: Bermudian Dollar: BERMUDA
    :cvar BND: Brunei Dollar: BRUNEI DARUSSALAM
    :cvar BOB: Boliviano: BOLIVIA, PLURINATIONAL STATE OF
    :cvar BOV: Mvdol: BOLIVIA, PLURINATIONAL STATE OF
    :cvar BRL: Brazilian Real: BRAZIL
    :cvar BSD: Bahamian Dollar: BAHAMAS
    :cvar BTN: Ngultrum: BHUTAN
    :cvar BWP: Pula: BOTSWANA
    :cvar BYN: Belarusian Ruble: BELARUS
    :cvar BYR: Historic use: Belarussian Ruble: BELARUS
    :cvar BZD: Belize Dollar: BELIZE
    :cvar CAD: Canadian Dollar: CANADA
    :cvar CDF: Congolese Franc: CONGO, THE DEMOCRATIC REPUBLIC OF
    :cvar CHE: WIR Euro: SWITZERLAND
    :cvar CHF: Swiss Franc: LIECHTENSTEIN; SWITZERLAND
    :cvar CHW: WIR Franc: SWITZERLAND
    :cvar CLF: Unidad de Fomento: CHILE
    :cvar CLP: Chilean Peso: CHILE
    :cvar CNY: Yuan Renminbi: CHINA
    :cvar COP: Colombian Peso: COLOMBIA
    :cvar COU: Unidad de Valor Real: COLOMBIA
    :cvar CRC: Costa Rican Colon: COSTA RICA
    :cvar CUC: Peso Convertible: CUBA
    :cvar CUP: Cuban Peso: CUBA
    :cvar CVE: Cabo Verde Escudo: CABO VERDE
    :cvar CZK: Czech Koruna: CZECHIA
    :cvar DJF: Djibouti Franc: DJIBOUTI
    :cvar DKK: Danish Krone: DENMARK; FAROE ISLANDS; GREENLAND
    :cvar DOP: Dominican Peso: DOMINICAN REPUBLIC
    :cvar DZD: Algerian Dinar: ALGERIA
    :cvar EGP: Egyptian Pound: EGYPT
    :cvar ERN: Nakfa: ERITREA
    :cvar ETB: Ethiopian Birr: ETHIOPIA
    :cvar EUR: Euro: ALAND ISLANDS; ANDORRA; AUSTRIA; BELGIUM; CYPRUS;
        ESTONIA; EUROPEAN UNION; FINLAND; FRANCE; FRENCH GUIANA; FRENCH
        SOUTHERN TERRITORIES; GERMANY; GREECE; GUADELOUPE; HOLY SEE
        (VATICAN CITY STATE); IRELAND; ITALY; LATVIA; LITHUANIA;
        LUXEMBOURG; MALTA; MARTINIQUE; MAYOTTE; MONACO; MONTENEGRO;
        NETHERLANDS; PORTUGAL; REUNION; SAINT BARTHELEMY; SAINT MARTIN
        (FRENCH PART); SAINT PIERRE AND MIQUELON; SAN MARINO; SLOVAKIA;
        SLOVENIA; SPAIN; Vatican City State (HOLY SEE)
    :cvar FJD: Fiji Dollar: FIJI
    :cvar FKP: Falkland Islands Pound: FALKLAND ISLANDS (MALVINAS)
    :cvar GBP: Pound Sterling: GUERNSEY; ISLE OF MAN; JERSEY; UNITED
        KINGDOM OF GREAT BRITAIN AND NORTHERN IRELAND
    :cvar GEL: Lari: GEORGIA
    :cvar GHS: Ghana Cedi: GHANA
    :cvar GIP: Gibraltar Pound: GIBRALTAR
    :cvar GMD: Dalasi: GAMBIA
    :cvar GNF: Guinean Franc: GUINEA
    :cvar GTQ: Quetzal: GUATEMALA
    :cvar GYD: Guyana Dollar: GUYANA
    :cvar HKD: Hong Kong Dollar: HONG KONG
    :cvar HNL: Lempira: HONDURAS
    :cvar HRK: Kuna: CROATIA
    :cvar HTG: Gourde: HAITI
    :cvar HUF: Forint: HUNGARY
    :cvar IDR: Rupiah: INDONESIA
    :cvar ILS: New Israeli Sheqel: ISRAEL
    :cvar INR: Indian Rupee: BHUTAN; INDIA
    :cvar IQD: Iraqi Dinar: IRAQ
    :cvar IRR: Iranian Rial: IRAN, ISLAMIC REPUBLIC OF
    :cvar ISK: Iceland Krona: ICELAND
    :cvar JMD: Jamaican Dollar: JAMAICA
    :cvar JOD: Jordanian Dinar: JORDAN
    :cvar JPY: Yen: JAPAN
    :cvar KES: Kenyan Shilling: KENYA
    :cvar KGS: Som: KYRGYZSTAN
    :cvar KHR: Riel: CAMBODIA
    :cvar KMF: Comorian Franc : COMOROS
    :cvar KPW: North Korean Won: KOREA, DEMOCRATIC PEOPLE’S REPUBLIC OF
    :cvar KRW: Won: KOREA, REPUBLIC OF
    :cvar KWD: Kuwaiti Dinar: KUWAIT
    :cvar KYD: Cayman Islands Dollar: CAYMAN ISLANDS
    :cvar KZT: Tenge: KAZAKHSTAN
    :cvar LAK: Lao Kip: LAO PEOPLE’S DEMOCRATIC REPUBLIC
    :cvar LBP: Lebanese Pound: LEBANON
    :cvar LKR: Sri Lanka Rupee: SRI LANKA
    :cvar LRD: Liberian Dollar: LIBERIA
    :cvar LSL: Loti: LESOTHO
    :cvar LTL: Historic use: Lithuanian Litas: LITHUANIA
    :cvar LVL: Historic use: Latvian Lats: LATVIA
    :cvar LYD: Libyan Dinar: LIBYA
    :cvar MAD: Moroccan Dirham: MOROCCO; WESTERN SAHARA
    :cvar MDL: Moldovan Leu: MOLDOVA, REPUBLIC OF
    :cvar MGA: Malagasy Ariary: MADAGASCAR
    :cvar MKD: Denar: MACEDONIA, THE FORMER YUGOSLAV REPUBLIC OF
    :cvar MMK: Kyat: MYANMAR
    :cvar MNT: Tugrik: MONGOLIA
    :cvar MOP: Pataca: MACAO
    :cvar MRO: Historic use: Ouguiya: MAURITANIA
    :cvar MRU: Ouguiya: MAURITANIA
    :cvar MUR: Mauritius Rupee: MAURITIUS
    :cvar MVR: Rufiyaa: MALDIVES
    :cvar MWK: Malawi Kwacha: MALAWI
    :cvar MXN: Mexican Peso: MEXICO
    :cvar MXV: Mexican Unidad de Inversion (UDI): MEXICO
    :cvar MYR: Malaysian Ringgit: MALAYSIA
    :cvar MZN: Mozambique Metical: MOZAMBIQUE
    :cvar NAD: Namibia Dollar: NAMIBIA
    :cvar NGN: Naira: NIGERIA
    :cvar NIO: Cordoba Oro: NICARAGUA
    :cvar NOK: Norwegian Krone: BOUVET ISLAND; NORWAY; SVALBARD AND JAN
        MAYEN
    :cvar NPR: Nepalese Rupee: NEPAL
    :cvar NZD: New Zealand Dollar: COOK ISLANDS; NEW ZEALAND; NIUE;
        PITCAIRN; TOKELAU
    :cvar OMR: Rial Omani: OMAN
    :cvar PAB: Balboa: PANAMA
    :cvar PEN: Sol: PERU
    :cvar PGK: Kina: PAPUA NEW GUINEA
    :cvar PHP: Philippine Peso: PHILIPPINES
    :cvar PKR: Pakistan Rupee: PAKISTAN
    :cvar PLN: Zloty: POLAND
    :cvar PYG: Guarani: PARAGUAY
    :cvar QAR: Qatari Rial: QATAR
    :cvar RON: Romanian Leu: ROMANIA
    :cvar RSD: Serbian Dinar: SERBIA
    :cvar RUB: Russian Ruble: RUSSIAN FEDERATION
    :cvar RWF: Rwanda Franc: RWANDA
    :cvar SAR: Saudi Riyal: SAUDI ARABIA
    :cvar SBD: Solomon Islands Dollar: SOLOMON ISLANDS
    :cvar SCR: Seychelles Rupee: SEYCHELLES
    :cvar SDG: Sudanese Pound: SUDAN
    :cvar SEK: Swedish Krona: SWEDEN
    :cvar SGD: Singapore Dollar: SINGAPORE
    :cvar SHP: Saint Helena Pound: SAINT HELENA, ASCENSION AND TRISTAN
        DA CUNHA
    :cvar SLL: Leone: SIERRA LEONE
    :cvar SOS: Somali Shilling: SOMALIA
    :cvar SRD: Surinam Dollar: SURINAME
    :cvar SSP: South Sudanese Pound: SOUTH SUDAN
    :cvar STD: Historic use: Dobra: SAO TOME AND PRINCIPE
    :cvar STN: Dobra: SAO TOME AND PRINCIPE
    :cvar SVC: El Salvador Colon: EL SALVADOR
    :cvar SYP: Syrian Pound: SYRIAN ARAB REPUBLIC
    :cvar SZL: Lilangeni: ESWATINI
    :cvar THB: Baht: THAILAND
    :cvar TJS: Somoni: TAJIKISTAN
    :cvar TMT: Turkmenistan New Manat: TURKMENISTAN
    :cvar TND: Tunisian Dinar: TUNISIA
    :cvar TOP: Pa’anga: TONGA
    :cvar TRY: Turkish Lira: TURKEY
    :cvar TTD: Trinidad and Tobago Dollar: TRINIDAD AND TOBAGO
    :cvar TWD: New Taiwan Dollar: TAIWAN, PROVINCE OF CHINA
    :cvar TZS: Tanzanian Shilling: TANZANIA, UNITED REPUBLIC OF
    :cvar UAH: Hryvnia: UKRAINE
    :cvar UGX: Uganda Shilling: UGANDA
    :cvar USD: US Dollar: AMERICAN SAMOA; BONAIRE; SINT EUSTATIUS AND
        SABA; BRITISH INDIAN OCEAN TERRITORY; ECUADOR; EL SALVADOR;
        GUAM; HAITI; MARSHALL ISLANDS; MICRONESIA, FEDERATED STATES OF;
        NORTHERN MARIANA ISLANDS; PALAU; PANAMA; PUERTO RICO; TIMOR-
        LESTE; TURKS AND CAICOS ISLANDS; UNITED STATES; UNITED STATES
        MINOR OUTLYING ISLANDS; VIRGIN ISLANDS (BRITISH); VIRGIN ISLANDS
        (US)
    :cvar USN: US Dollar (Next day): UNITED STATES
    :cvar USS: Historic use: US Dollar (Same day): UNITED STATES
    :cvar UYI: Uruguay Peso en Unidades Indexadas (UI): URUGUAY
    :cvar UYU: Peso Uruguayo: URUGUAY
    :cvar UYW: Unidad Previsional: URUGUAY
    :cvar UZS: Uzbekistan Sum: UZBEKISTAN
    :cvar VEF: Historic use: Bolivar: VENEZUELA, BOLIVARIAN REPUBLIC OF
    :cvar VES: Bolívar Soberano: VENEZUELA, BOLIVARIAN REPUBLIC OF
    :cvar VND: Dong: VIET NAM
    :cvar VUV: Vatu: VANUATU
    :cvar WST: Tala: SAMOA
    :cvar XAF: CFA Franc BEAC: CAMEROON; CENTRAL AFRICAN REPUBLIC; CHAD;
        CONGO; EQUATORIAL GUINEA; GABON
    :cvar XAG: Silver: ZZ11_Silver
    :cvar XAU: Gold: ZZ08_Gold
    :cvar XBA: Bond Markets Unit European Composite Unit (EURCO):
        ZZ01_Bond Markets Unit European_EURCO
    :cvar XBB: Bond Markets Unit European Monetary Unit (E.M.U.-6):
        ZZ02_Bond Markets Unit European_EMU-6
    :cvar XBC: Bond Markets Unit European Unit of Account 9 (E.U.A.-9):
        ZZ03_Bond Markets Unit European_EUA-9
    :cvar XBD: Bond Markets Unit European Unit of Account 17
        (E.U.A.-17): ZZ04_Bond Markets Unit European_EUA-17
    :cvar XCD: East Caribbean Dollar: ANGUILLA; ANTIGUA AND BARBUDA;
        DOMINICA; GRENADA; MONTSERRAT; SAINT KITTS AND NEVIS; SAINT
        LUCIA; SAINT VINCENT AND THE GRENADINES
    :cvar XDR: SDR (Special Drawing Right): INTERNATIONAL MONETARY FUND
        (IMF)
    :cvar XFU: Historic use: UIC-Franc: ZZ05_UIC-Franc
    :cvar XOF: CFA Franc BCEAO: BENIN; BURKINA FASO; COTE D'IVOIRE;
        GUINEA-BISSAU; MALI; NIGER; SENEGAL; TOGO
    :cvar XPD: Palladium: ZZ09_Palladium
    :cvar XPF: CFP Franc: FRENCH POLYNESIA; NEW CALEDONIA; WALLIS AND
        FUTUNA
    :cvar XPT: Platinum: ZZ10_Platinum
    :cvar XSU: Sucre: SISTEMA UNITARIO DE COMPENSACION REGIONAL DE PAGOS
        "SUCRE"
    :cvar XUA: ADB Unit of Account: MEMBER COUNTRIES OF THE AFRICAN
        DEVELOPMENT BANK GROUP
    :cvar XXX: The codes assigned for transactions where no currency is
        involved: ZZ07_No_Currency
    :cvar YER: Yemeni Rial: YEMEN
    :cvar ZAR: Rand: LESOTHO; NAMIBIA; SOUTH AFRICA
    :cvar ZMW: Zambian Kwacha: ZAMBIA
    :cvar ZWL: Zimbabwe Dollar: ZIMBABWE
    """

    AED = "AED"
    AFN = "AFN"
    ALL = "ALL"
    AMD = "AMD"
    ANG = "ANG"
    AOA = "AOA"
    ARS = "ARS"
    AUD = "AUD"
    AWG = "AWG"
    AZN = "AZN"
    BAM = "BAM"
    BBD = "BBD"
    BDT = "BDT"
    BGN = "BGN"
    BHD = "BHD"
    BIF = "BIF"
    BMD = "BMD"
    BND = "BND"
    BOB = "BOB"
    BOV = "BOV"
    BRL = "BRL"
    BSD = "BSD"
    BTN = "BTN"
    BWP = "BWP"
    BYN = "BYN"
    BYR = "BYR"
    BZD = "BZD"
    CAD = "CAD"
    CDF = "CDF"
    CHE = "CHE"
    CHF = "CHF"
    CHW = "CHW"
    CLF = "CLF"
    CLP = "CLP"
    CNY = "CNY"
    COP = "COP"
    COU = "COU"
    CRC = "CRC"
    CUC = "CUC"
    CUP = "CUP"
    CVE = "CVE"
    CZK = "CZK"
    DJF = "DJF"
    DKK = "DKK"
    DOP = "DOP"
    DZD = "DZD"
    EGP = "EGP"
    ERN = "ERN"
    ETB = "ETB"
    EUR = "EUR"
    FJD = "FJD"
    FKP = "FKP"
    GBP = "GBP"
    GEL = "GEL"
    GHS = "GHS"
    GIP = "GIP"
    GMD = "GMD"
    GNF = "GNF"
    GTQ = "GTQ"
    GYD = "GYD"
    HKD = "HKD"
    HNL = "HNL"
    HRK = "HRK"
    HTG = "HTG"
    HUF = "HUF"
    IDR = "IDR"
    ILS = "ILS"
    INR = "INR"
    IQD = "IQD"
    IRR = "IRR"
    ISK = "ISK"
    JMD = "JMD"
    JOD = "JOD"
    JPY = "JPY"
    KES = "KES"
    KGS = "KGS"
    KHR = "KHR"
    KMF = "KMF"
    KPW = "KPW"
    KRW = "KRW"
    KWD = "KWD"
    KYD = "KYD"
    KZT = "KZT"
    LAK = "LAK"
    LBP = "LBP"
    LKR = "LKR"
    LRD = "LRD"
    LSL = "LSL"
    LTL = "LTL"
    LVL = "LVL"
    LYD = "LYD"
    MAD = "MAD"
    MDL = "MDL"
    MGA = "MGA"
    MKD = "MKD"
    MMK = "MMK"
    MNT = "MNT"
    MOP = "MOP"
    MRO = "MRO"
    MRU = "MRU"
    MUR = "MUR"
    MVR = "MVR"
    MWK = "MWK"
    MXN = "MXN"
    MXV = "MXV"
    MYR = "MYR"
    MZN = "MZN"
    NAD = "NAD"
    NGN = "NGN"
    NIO = "NIO"
    NOK = "NOK"
    NPR = "NPR"
    NZD = "NZD"
    OMR = "OMR"
    PAB = "PAB"
    PEN = "PEN"
    PGK = "PGK"
    PHP = "PHP"
    PKR = "PKR"
    PLN = "PLN"
    PYG = "PYG"
    QAR = "QAR"
    RON = "RON"
    RSD = "RSD"
    RUB = "RUB"
    RWF = "RWF"
    SAR = "SAR"
    SBD = "SBD"
    SCR = "SCR"
    SDG = "SDG"
    SEK = "SEK"
    SGD = "SGD"
    SHP = "SHP"
    SLL = "SLL"
    SOS = "SOS"
    SRD = "SRD"
    SSP = "SSP"
    STD = "STD"
    STN = "STN"
    SVC = "SVC"
    SYP = "SYP"
    SZL = "SZL"
    THB = "THB"
    TJS = "TJS"
    TMT = "TMT"
    TND = "TND"
    TOP = "TOP"
    TRY = "TRY"
    TTD = "TTD"
    TWD = "TWD"
    TZS = "TZS"
    UAH = "UAH"
    UGX = "UGX"
    USD = "USD"
    USN = "USN"
    USS = "USS"
    UYI = "UYI"
    UYU = "UYU"
    UYW = "UYW"
    UZS = "UZS"
    VEF = "VEF"
    VES = "VES"
    VND = "VND"
    VUV = "VUV"
    WST = "WST"
    XAF = "XAF"
    XAG = "XAG"
    XAU = "XAU"
    XBA = "XBA"
    XBB = "XBB"
    XBC = "XBC"
    XBD = "XBD"
    XCD = "XCD"
    XDR = "XDR"
    XFU = "XFU"
    XOF = "XOF"
    XPD = "XPD"
    XPF = "XPF"
    XPT = "XPT"
    XSU = "XSU"
    XUA = "XUA"
    XXX = "XXX"
    YER = "YER"
    ZAR = "ZAR"
    ZMW = "ZMW"
    ZWL = "ZWL"


@dataclass(kw_only=True)
class AddressType:
    """
    The user has the option to enter the data about the address of a party
    either as one long field or to spread the data over up to eight
    elements or even to use both formats.

    If the user chooses the option to enter the data required in separate
    elements, the container element for this will be 'AddressFix'. If the
    user chooses the option to enter the data required in a less structured
    way in 'AddressFree' all available address details shall be presented
    as one string of bytes, blank or "/" (slash) or carriage return- line
    feed used as a delimiter between parts of the address. PLEASE NOTE that
    the address country code is outside both of these elements. The use of
    the fixed form is recommended as a rule to allow easy matching.
    However, the use of the free form is recommended if the sending state
    cannot reliably identify and distinguish the different parts of the
    address. The user may want to use both formats e.g. if besides
    separating the logical parts of the address he also wants to indicate a
    suitable breakdown into print-lines by delimiters in the free text
    form. In this case 'AddressFix' has to precede 'AddressFree'.
    """

    class Meta:
        name = "Address_Type"
        target_namespace = "urn:oecd:ties:commontypesfatcacrs:v2"

    country_code: CountryCodeType = field(
        metadata={
            "name": "CountryCode",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
        }
    )
    address_fix: None | AddressFixType = field(
        default=None,
        metadata={
            "name": "AddressFix",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
        },
    )
    address_free: None | str = field(
        default=None,
        metadata={
            "name": "AddressFree",
            "type": "Element",
            "namespace": "urn:oecd:ties:commontypesfatcacrs:v2",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    legal_address_type: None | OecdlegalAddressTypeEnumType = field(
        default=None,
        metadata={
            "name": "legalAddressType",
            "type": "Attribute",
        },
    )


@dataclass(kw_only=True)
class MonAmntType:
    """
    This data type is to be used whenever monetary amounts are to be
    communicated.

    Such amounts shall be given including two fractional digits of the main
    currency unit. The code for the currency in which the value is
    expressed has to be taken from the ISO codelist 4217 and added in
    attribute currCode.
    """

    class Meta:
        name = "MonAmnt_Type"
        target_namespace = "urn:oecd:ties:commontypesfatcacrs:v2"

    value: Decimal = field(
        metadata={
            "fraction_digits": 2,
        }
    )
    curr_code: CurrCodeType = field(
        metadata={
            "name": "currCode",
            "type": "Attribute",
        }
    )


@dataclass(kw_only=True)
class NameOrganisationType:
    """
    Name of organisation.
    """

    class Meta:
        name = "NameOrganisation_Type"
        target_namespace = "urn:oecd:ties:commontypesfatcacrs:v2"

    value: str = field(
        default="",
        metadata={
            "min_length": 1,
            "max_length": 200,
        },
    )
    name_type: None | OecdnameTypeEnumType = field(
        default=None,
        metadata={
            "name": "nameType",
            "type": "Attribute",
        },
    )


@dataclass(kw_only=True)
class TinType:
    """
    This is the identification number/identification code for the party in
    question.

    As the identifier may be not strictly numeric, it is just defined as a
    string of characters. Attribute 'issuedBy' is required to designate the
    issuer of the identifier.

    :ivar value:
    :ivar issued_by: Country code of issuing country, indicating country
        of Residence (to taxes and other)
    """

    class Meta:
        name = "TIN_Type"
        target_namespace = "urn:oecd:ties:commontypesfatcacrs:v2"

    value: str = field(
        default="",
        metadata={
            "min_length": 1,
            "max_length": 200,
        },
    )
    issued_by: None | CountryCodeType = field(
        default=None,
        metadata={
            "name": "issuedBy",
            "type": "Attribute",
        },
    )


@dataclass(kw_only=True)
class FiaccountNumberType:
    """
    Account number definition.

    :ivar value:
    :ivar acct_number_type: Account Number Type
    :ivar undocumented_account: Undocumented Account
    :ivar closed_account: Closed Account
    :ivar dormant_account: Dormant Account
    """

    class Meta:
        name = "FIAccountNumber_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    value: str = field(
        default="",
        metadata={
            "min_length": 1,
            "max_length": 200,
        },
    )
    acct_number_type: None | AcctNumberTypeEnumType = field(
        default=None,
        metadata={
            "name": "AcctNumberType",
            "type": "Attribute",
        },
    )
    undocumented_account: None | bool = field(
        default=None,
        metadata={
            "name": "UndocumentedAccount",
            "type": "Attribute",
        },
    )
    closed_account: None | bool = field(
        default=None,
        metadata={
            "name": "ClosedAccount",
            "type": "Attribute",
        },
    )
    dormant_account: None | bool = field(
        default=None,
        metadata={
            "name": "DormantAccount",
            "type": "Attribute",
        },
    )


@dataclass(kw_only=True)
class MessageSpecType:
    """
    Information in the message header identifies the Tax Administration
    that is sending the message.

    It specifies when the message was created, what period (normally a
    year) the report is for, and the nature of the report (original,
    corrected, supplemental, etc).

    :ivar sending_company_in:
    :ivar transmitting_country:
    :ivar receiving_country:
    :ivar message_type:
    :ivar warning: Free text expressing the restrictions for use of the
        information this message contains and the legal framework under
        which it is given
    :ivar contact: All necessary contact information about persons
        responsible for and involved in the processing of the data
        transmitted in this message, both legally and technically. Free
        text as this is not intended for automatic processing.
    :ivar message_ref_id: Sender's unique identifier for this message
    :ivar message_type_indic:
    :ivar corr_message_ref_id: Sender's unique identifier that has to be
        corrected.  Must point to 1 or more previous message
    :ivar reporting_period: The reporting year for which information is
        transmitted in documents of the current message.
    :ivar timestamp:
    """

    class Meta:
        name = "MessageSpec_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    sending_company_in: None | str = field(
        default=None,
        metadata={
            "name": "SendingCompanyIN",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    transmitting_country: CountryCodeType = field(
        metadata={
            "name": "TransmittingCountry",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    receiving_country: CountryCodeType = field(
        metadata={
            "name": "ReceivingCountry",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    message_type: MessageTypeEnumType = field(
        metadata={
            "name": "MessageType",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    warning: None | str = field(
        default=None,
        metadata={
            "name": "Warning",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    contact: None | str = field(
        default=None,
        metadata={
            "name": "Contact",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 4000,
        },
    )
    message_ref_id: str = field(
        metadata={
            "name": "MessageRefId",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 170,
        }
    )
    message_type_indic: CrsMessageTypeIndicEnumType = field(
        metadata={
            "name": "MessageTypeIndic",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    corr_message_ref_id: list[str] = field(
        default_factory=list,
        metadata={
            "name": "CorrMessageRefId",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 170,
        },
    )
    reporting_period: XmlDate = field(
        metadata={
            "name": "ReportingPeriod",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    timestamp: XmlDateTime = field(
        metadata={
            "name": "Timestamp",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )


@dataclass(kw_only=True)
class NamePersonType:
    """
    The user must spread the data about the name of a party over up to six
    elements.

    The container element for this will be 'NameFix'.

    :ivar preceding_title: His Excellency,Estate of the Late ...
    :ivar title: Greeting title. Example: Mr, Dr, Ms, Herr, etc. Can
        have multiple titles.
    :ivar first_name: FirstName of the person
    :ivar middle_name: Middle name (essential part of the name for many
        nationalities). Example: Sakthi in "Nivetha Sakthi Shantha". Can
        have multiple middle names.
    :ivar name_prefix: de, van, van de, von, etc. Example: Derick de
        Clarke
    :ivar last_name: Represents the position of the name in a name
        string. Can be Given Name, Forename, Christian Name, Surname,
        Family Name, etc. Use the attribute "NameType" to define what
        type this name is. In case of a company, this field can be used
        for the company name.
    :ivar generation_identifier: Jnr, Thr Third, III
    :ivar suffix: Could be compressed initials - PhD, VC, QC
    :ivar general_suffix: Deceased, Retired ...
    :ivar name_type:
    """

    class Meta:
        name = "NamePerson_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    preceding_title: None | str = field(
        default=None,
        metadata={
            "name": "PrecedingTitle",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    title: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Title",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    first_name: NamePersonType.FirstName = field(
        metadata={
            "name": "FirstName",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    middle_name: list[NamePersonType.MiddleName] = field(
        default_factory=list,
        metadata={
            "name": "MiddleName",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    name_prefix: None | NamePersonType.NamePrefix = field(
        default=None,
        metadata={
            "name": "NamePrefix",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    last_name: NamePersonType.LastName = field(
        metadata={
            "name": "LastName",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    generation_identifier: list[str] = field(
        default_factory=list,
        metadata={
            "name": "GenerationIdentifier",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    suffix: list[str] = field(
        default_factory=list,
        metadata={
            "name": "Suffix",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    general_suffix: None | str = field(
        default=None,
        metadata={
            "name": "GeneralSuffix",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_length": 1,
            "max_length": 200,
        },
    )
    name_type: None | OecdnameTypeEnumType = field(
        default=None,
        metadata={
            "name": "nameType",
            "type": "Attribute",
        },
    )

    @dataclass(kw_only=True)
    class FirstName:
        """
        :ivar value:
        :ivar xnl_name_type: Defines the name type of FirstName.
            Example: Given Name, Forename, Christian Name, Father's
            Name, etc. In some countries, FirstName could be a Family
            Name or a SurName. Use this attribute to define the type for
            this name.
        """

        value: str = field(
            default="",
            metadata={
                "min_length": 1,
                "max_length": 200,
            },
        )
        xnl_name_type: None | str = field(
            default=None,
            metadata={
                "name": "xnlNameType",
                "type": "Attribute",
                "min_length": 1,
                "max_length": 200,
            },
        )

    @dataclass(kw_only=True)
    class MiddleName:
        """
        :ivar value:
        :ivar xnl_name_type: Defines the name type of Middle Name.
            Example: First name, middle name, maiden name, father's
            name, given name, etc.
        """

        value: str = field(
            default="",
            metadata={
                "min_length": 1,
                "max_length": 200,
            },
        )
        xnl_name_type: None | str = field(
            default=None,
            metadata={
                "name": "xnlNameType",
                "type": "Attribute",
                "min_length": 1,
                "max_length": 200,
            },
        )

    @dataclass(kw_only=True)
    class NamePrefix:
        """
        :ivar value:
        :ivar xnl_name_type: Defines the type of name associated with
            the NamePrefix. For example the type of name is LastName and
            this prefix is the prefix for this last name.
        """

        value: str = field(
            default="",
            metadata={
                "min_length": 1,
                "max_length": 200,
            },
        )
        xnl_name_type: None | str = field(
            default=None,
            metadata={
                "name": "xnlNameType",
                "type": "Attribute",
                "min_length": 1,
                "max_length": 200,
            },
        )

    @dataclass(kw_only=True)
    class LastName:
        """
        :ivar value:
        :ivar xnl_name_type: Defines the name type of LastName. Example:
            Father's name, Family name, Sur Name, Mother's Name, etc. In
            some countries, LastName could be the given name or first
            name.
        """

        value: str = field(
            default="",
            metadata={
                "min_length": 1,
                "max_length": 200,
            },
        )
        xnl_name_type: None | str = field(
            default=None,
            metadata={
                "name": "xnlNameType",
                "type": "Attribute",
                "min_length": 1,
                "max_length": 200,
            },
        )


@dataclass(kw_only=True)
class OrganisationInType:
    """
    This is the identification number/identification code for the Entity in
    question.

    As the identifier may be not strictly numeric, it is just defined as a
    string of characters. Attribute 'issuedBy' is required to designate the
    issuer of the identifier. Attribute 'INType' defines the type of
    identification number.

    :ivar value:
    :ivar issued_by: Country code of issuing country, indicating country
        of Residence (to taxes and other)
    :ivar intype: Identification Number Type
    """

    class Meta:
        name = "OrganisationIN_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    value: str = field(
        default="",
        metadata={
            "min_length": 1,
            "max_length": 200,
        },
    )
    issued_by: None | CountryCodeType = field(
        default=None,
        metadata={
            "name": "issuedBy",
            "type": "Attribute",
        },
    )
    intype: None | str = field(
        default=None,
        metadata={
            "name": "INType",
            "type": "Attribute",
            "min_length": 1,
            "max_length": 200,
        },
    )


@dataclass(kw_only=True)
class DocSpecType:
    """
    Document specification: Data identifying and describing the document,
    where 'document' here means the part of a message that is to transmit
    the data about a single block of CRS information.

    :ivar doc_type_indic:
    :ivar doc_ref_id: Sender's unique identifier of this document
    :ivar corr_message_ref_id: Reference id of the message of the
        document referred to if this is a correction
    :ivar corr_doc_ref_id: Reference id of the document referred to if
        this is correction
    """

    class Meta:
        name = "DocSpec_Type"
        target_namespace = "urn:oecd:ties:crsstf:v5"

    doc_type_indic: OecddocTypeIndicEnumType = field(
        metadata={
            "name": "DocTypeIndic",
            "type": "Element",
            "namespace": "urn:oecd:ties:crsstf:v5",
        }
    )
    doc_ref_id: str = field(
        metadata={
            "name": "DocRefId",
            "type": "Element",
            "namespace": "urn:oecd:ties:crsstf:v5",
            "min_length": 1,
            "max_length": 200,
        }
    )
    corr_message_ref_id: None | str = field(
        default=None,
        metadata={
            "name": "CorrMessageRefId",
            "type": "Element",
            "namespace": "urn:oecd:ties:crsstf:v5",
            "min_length": 1,
            "max_length": 170,
        },
    )
    corr_doc_ref_id: None | str = field(
        default=None,
        metadata={
            "name": "CorrDocRefId",
            "type": "Element",
            "namespace": "urn:oecd:ties:crsstf:v5",
            "min_length": 1,
            "max_length": 200,
        },
    )


@dataclass(kw_only=True)
class OrganisationPartyType:
    """
    This container brings together all data about an organisation as a
    party.

    Name and address are required components and each can be present more
    than once to enable as complete a description as possible. Whenever
    possible one or more identifiers (TIN etc) should be added as well as a
    residence country code. Additional data that describes and identifies
    the party can be given . The code for the legal type according to the
    OECD codelist must be added. The structures of all of the subelements
    are defined elsewhere in this schema.

    :ivar res_country_code:
    :ivar in_value: Entity Identification Number
    :ivar name:
    :ivar address:
    """

    class Meta:
        name = "OrganisationParty_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    res_country_code: list[CountryCodeType] = field(
        default_factory=list,
        metadata={
            "name": "ResCountryCode",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    in_value: list[OrganisationInType] = field(
        default_factory=list,
        metadata={
            "name": "IN",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    name: list[NameOrganisationType] = field(
        default_factory=list,
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )
    address: list[AddressType] = field(
        default_factory=list,
        metadata={
            "name": "Address",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )


@dataclass(kw_only=True)
class PaymentType:
    """
    :ivar type_value: Type of payment (interest, dividend,...)
    :ivar payment_amnt: The amount of payment
    """

    class Meta:
        name = "Payment_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    type_value: CrsPaymentTypeEnumType = field(
        metadata={
            "name": "Type",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    payment_amnt: MonAmntType = field(
        metadata={
            "name": "PaymentAmnt",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )


@dataclass(kw_only=True)
class PersonPartyType:
    """
    This container brings together all data about a person as a party.

    Name and address are required components and each can be present more
    than once to enable as complete a description as possible. Whenever
    possible one or more identifiers (TIN etc) should be added as well as a
    residence country code. Additional data that describes and identifies
    the party can be given. The code for the legal type according to the
    OECD codelist must be added. The structures of all of the subelements
    are defined elsewhere in this schema.
    """

    class Meta:
        name = "PersonParty_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    res_country_code: list[CountryCodeType] = field(
        default_factory=list,
        metadata={
            "name": "ResCountryCode",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )
    tin: list[TinType] = field(
        default_factory=list,
        metadata={
            "name": "TIN",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    name: list[NamePersonType] = field(
        default_factory=list,
        metadata={
            "name": "Name",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )
    address: list[AddressType] = field(
        default_factory=list,
        metadata={
            "name": "Address",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )
    nationality: list[CountryCodeType] = field(
        default_factory=list,
        metadata={
            "name": "Nationality",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    birth_info: None | PersonPartyType.BirthInfo = field(
        default=None,
        metadata={
            "name": "BirthInfo",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )

    @dataclass(kw_only=True)
    class BirthInfo:
        birth_date: None | XmlDate = field(
            default=None,
            metadata={
                "name": "BirthDate",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )
        city: None | str = field(
            default=None,
            metadata={
                "name": "City",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
                "min_length": 1,
                "max_length": 200,
            },
        )
        city_subentity: None | str = field(
            default=None,
            metadata={
                "name": "CitySubentity",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
                "min_length": 1,
                "max_length": 200,
            },
        )
        country_info: None | PersonPartyType.BirthInfo.CountryInfo = field(
            default=None,
            metadata={
                "name": "CountryInfo",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )

        @dataclass(kw_only=True)
        class CountryInfo:
            country_code: None | CountryCodeType = field(
                default=None,
                metadata={
                    "name": "CountryCode",
                    "type": "Element",
                    "namespace": "urn:oecd:ties:crs:v2",
                },
            )
            former_country_name: None | str = field(
                default=None,
                metadata={
                    "name": "FormerCountryName",
                    "type": "Element",
                    "namespace": "urn:oecd:ties:crs:v2",
                    "min_length": 1,
                    "max_length": 200,
                },
            )


@dataclass(kw_only=True)
class CorrectablePoolReportType:
    class Meta:
        name = "CorrectablePoolReport_Type"
        target_namespace = "urn:oecd:ties:fatca:v1"

    doc_spec: DocSpecType = field(
        metadata={
            "name": "DocSpec",
            "type": "Element",
            "namespace": "urn:oecd:ties:fatca:v1",
        }
    )
    account_count: int = field(
        metadata={
            "name": "AccountCount",
            "type": "Element",
            "namespace": "urn:oecd:ties:fatca:v1",
        }
    )
    account_pool_report_type: FatcaAcctPoolReportTypeEnumType = field(
        metadata={
            "name": "AccountPoolReportType",
            "type": "Element",
            "namespace": "urn:oecd:ties:fatca:v1",
        }
    )
    pool_balance: MonAmntType = field(
        metadata={
            "name": "PoolBalance",
            "type": "Element",
            "namespace": "urn:oecd:ties:fatca:v1",
        }
    )


@dataclass(kw_only=True)
class AccountHolderType:
    class Meta:
        name = "AccountHolder_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    individual: None | PersonPartyType = field(
        default=None,
        metadata={
            "name": "Individual",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    organisation: None | OrganisationPartyType = field(
        default=None,
        metadata={
            "name": "Organisation",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    acct_holder_type: None | CrsAcctHolderTypeEnumType = field(
        default=None,
        metadata={
            "name": "AcctHolderType",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )


@dataclass(kw_only=True)
class ControllingPersonType:
    class Meta:
        name = "ControllingPerson_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    individual: PersonPartyType = field(
        metadata={
            "name": "Individual",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    ctrlg_person_type: None | CrsCtrlgPersonTypeEnumType = field(
        default=None,
        metadata={
            "name": "CtrlgPersonType",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )


@dataclass(kw_only=True)
class CorrectableOrganisationPartyType(OrganisationPartyType):
    class Meta:
        name = "CorrectableOrganisationParty_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    doc_spec: DocSpecType = field(
        metadata={
            "name": "DocSpec",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )


@dataclass(kw_only=True)
class CorrectableAccountReportType:
    class Meta:
        name = "CorrectableAccountReport_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    doc_spec: DocSpecType = field(
        metadata={
            "name": "DocSpec",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    account_number: FiaccountNumberType = field(
        metadata={
            "name": "AccountNumber",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    account_holder: AccountHolderType = field(
        metadata={
            "name": "AccountHolder",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    controlling_person: list[ControllingPersonType] = field(
        default_factory=list,
        metadata={
            "name": "ControllingPerson",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )
    account_balance: MonAmntType = field(
        metadata={
            "name": "AccountBalance",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    payment: list[PaymentType] = field(
        default_factory=list,
        metadata={
            "name": "Payment",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        },
    )


@dataclass(kw_only=True)
class CrsBodyType:
    """
    :ivar reporting_fi: Reporting financial institution
    :ivar reporting_group: For CRS, only one ReportingGroup for each
        CrsBody is to be provided
    """

    class Meta:
        name = "CrsBody_Type"
        target_namespace = "urn:oecd:ties:crs:v2"

    reporting_fi: CorrectableOrganisationPartyType = field(
        metadata={
            "name": "ReportingFI",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
        }
    )
    reporting_group: list[CrsBodyType.ReportingGroup] = field(
        default_factory=list,
        metadata={
            "name": "ReportingGroup",
            "type": "Element",
            "namespace": "urn:oecd:ties:crs:v2",
            "min_occurs": 1,
        },
    )

    @dataclass(kw_only=True)
    class ReportingGroup:
        sponsor: None | CorrectableOrganisationPartyType = field(
            default=None,
            metadata={
                "name": "Sponsor",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )
        intermediary: None | CorrectableOrganisationPartyType = field(
            default=None,
            metadata={
                "name": "Intermediary",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )
        account_report: list[CorrectableAccountReportType] = field(
            default_factory=list,
            metadata={
                "name": "AccountReport",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )
        pool_report: list[CorrectablePoolReportType] = field(
            default_factory=list,
            metadata={
                "name": "PoolReport",
                "type": "Element",
                "namespace": "urn:oecd:ties:crs:v2",
            },
        )


@dataclass(kw_only=True)
class CrsOecd:
    """
    :ivar message_spec:
    :ivar crs_body:
    :ivar version: CRS Version
    """

    class Meta:
        name = "CRS_OECD"
        namespace = "urn:oecd:ties:crs:v2"

    message_spec: MessageSpecType = field(
        metadata={
            "name": "MessageSpec",
            "type": "Element",
        }
    )
    crs_body: list[CrsBodyType] = field(
        default_factory=list,
        metadata={
            "name": "CrsBody",
            "type": "Element",
        },
    )
    version: None | str = field(
        default=None,
        metadata={
            "type": "Attribute",
            "min_length": 1,
            "max_length": 10,
        },
    )
